"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_interfaces_interfaces_module_ts"],{

/***/ 553:
/*!*************************************************!*\
  !*** ./src/app/interfaces/interfaces.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   InterfacesPageModule: () => (/* binding */ InterfacesPageModule)
/* harmony export */ });
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ionic/angular */ 1507);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 3683);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 4456);
/* harmony import */ var _interfaces_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./interfaces.page */ 8482);
/* harmony import */ var _explore_container_explore_container_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../explore-container/explore-container.module */ 1307);
/* harmony import */ var _interfaces_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./interfaces-routing.module */ 2776);
/* harmony import */ var _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/cdk/scrolling */ 9975);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 4205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2481);
var _staticBlock;








class InterfacesPageModule {
  static #_ = _staticBlock = () => (this.ɵfac = function InterfacesPageModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || InterfacesPageModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵdefineNgModule"]({
    type: InterfacesPageModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineInjector"]({
    imports: [_ionic_angular__WEBPACK_IMPORTED_MODULE_0__.IonicModule, _angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormsModule, _explore_container_explore_container_module__WEBPACK_IMPORTED_MODULE_4__.ExploreContainerComponentModule, _interfaces_routing_module__WEBPACK_IMPORTED_MODULE_5__.InterfacesPageRoutingModule, _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_6__.ScrollingModule, _interfaces_page__WEBPACK_IMPORTED_MODULE_3__.InterfacesPage]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_8__["ɵɵsetNgModuleScope"](InterfacesPageModule, {
    imports: [_ionic_angular__WEBPACK_IMPORTED_MODULE_0__.IonicModule, _angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormsModule, _explore_container_explore_container_module__WEBPACK_IMPORTED_MODULE_4__.ExploreContainerComponentModule, _interfaces_routing_module__WEBPACK_IMPORTED_MODULE_5__.InterfacesPageRoutingModule, _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_6__.ScrollingModule, _interfaces_page__WEBPACK_IMPORTED_MODULE_3__.InterfacesPage]
  });
})();

/***/ }),

/***/ 2776:
/*!*********************************************************!*\
  !*** ./src/app/interfaces/interfaces-routing.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   InterfacesPageRoutingModule: () => (/* binding */ InterfacesPageRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ 4487);
/* harmony import */ var _interfaces_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./interfaces.page */ 8482);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2481);
var _staticBlock;




const routes = [{
  path: '',
  component: _interfaces_page__WEBPACK_IMPORTED_MODULE_1__.InterfacesPage
}];
class InterfacesPageRoutingModule {
  static #_ = _staticBlock = () => (this.ɵfac = function InterfacesPageRoutingModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || InterfacesPageRoutingModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
    type: InterfacesPageRoutingModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule.forChild(routes), _angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](InterfacesPageRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  });
})();

/***/ }),

/***/ 3985:
/*!***************************************************************************************!*\
  !*** ./src/app/interfaces/interface-detail-modal/interface-detail-modal.component.ts ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   InterfaceDetailModalComponent: () => (/* binding */ InterfaceDetailModalComponent)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ 3683);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ 4456);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 1507);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 5797);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 9452);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ 1318);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 3037);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 6647);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 8764);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 4205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 2481);
/* harmony import */ var _services_opmanager_api_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../services/opmanager-api.service */ 5793);
var _staticBlock;









function InterfaceDetailModalComponent_div_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 5);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](1, "ion-spinner", 6);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
}
function InterfaceDetailModalComponent_ng_container_10_ion_select_option_82_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "ion-select-option", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const period_r3 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("value", period_r3.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", period_r3.name, " ");
  }
}
function InterfaceDetailModalComponent_ng_container_10_ng_container_88_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 19)(1, "p", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](2, "Gr\u00E1fica de Tr\u00E1fico (Rx/Tx)");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](3, "small", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const graphData_r4 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]().ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"]("Unidad: ", graphData_r4["suffix"] || "bytes");
  }
}
function InterfaceDetailModalComponent_ng_container_10_ng_container_88_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 21)(1, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](2, "No hay datos de gr\u00E1fica disponibles");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
}
function InterfaceDetailModalComponent_ng_container_10_ng_container_88_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](1, InterfaceDetailModalComponent_ng_container_10_ng_container_88_div_1_Template, 5, 1, "div", 17)(2, InterfaceDetailModalComponent_ng_container_10_ng_container_88_div_2_Template, 3, 0, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const graphData_r4 = ctx.ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", graphData_r4 && graphData_r4["graphData"] && graphData_r4["graphData"].length > 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", !graphData_r4 || !graphData_r4["graphData"] || graphData_r4["graphData"].length === 0);
  }
}
function InterfaceDetailModalComponent_ng_container_10_ng_container_95_div_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 19)(1, "p", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](2, "Gr\u00E1fica de Utilizaci\u00F3n");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](3, "small", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const graphData_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]().ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"]("Unidad: ", graphData_r5["suffix"] || "porcentaje");
  }
}
function InterfaceDetailModalComponent_ng_container_10_ng_container_95_div_2_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "div", 21)(1, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](2, "No hay datos de gr\u00E1fica disponibles");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
  }
}
function InterfaceDetailModalComponent_ng_container_10_ng_container_95_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](1, InterfaceDetailModalComponent_ng_container_10_ng_container_95_div_1_Template, 5, 1, "div", 17)(2, InterfaceDetailModalComponent_ng_container_10_ng_container_95_div_2_Template, 3, 0, "div", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const graphData_r5 = ctx.ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", graphData_r5 && graphData_r5["graphData"] && graphData_r5["graphData"].length > 0);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", !graphData_r5 || !graphData_r5["graphData"] || graphData_r5["graphData"].length === 0);
  }
}
function InterfaceDetailModalComponent_ng_container_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](1, "ion-card")(2, "ion-card-header")(3, "ion-card-title");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](4, "Informaci\u00F3n General");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](5, "ion-card-content")(6, "ion-row")(7, "ion-col", 7)(8, "div", 8)(9, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](10, "Nombre:");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](11);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](12, "div", 8)(13, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](14, "Alias:");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](16, "div", 8)(17, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](18, "Descripci\u00F3n:");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](19);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](20, "div", 8)(21, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](22, "Tipo:");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](23);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](24, "ion-col", 7)(25, "div", 8)(26, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](27, "Estado:");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](28, "ion-badge", 9);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](29);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](30, "div", 8)(31, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](32, "Velocidad Entrada:");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](33);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](34, "div", 8)(35, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](36, "Velocidad Salida:");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](37);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](38, "div", 8)(39, "strong");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](40, "IP Address:");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](41);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](42, "ion-card")(43, "ion-card-header")(44, "ion-card-title");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](45, "M\u00E9tricas de Desempe\u00F1o");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](46, "ion-card-content")(47, "ion-row")(48, "ion-col", 10)(49, "div", 11)(50, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](51, "Utilizaci\u00F3n");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](52, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](53);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](54, "ion-col", 10)(55, "div", 11)(56, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](57, "Tr\u00E1fico Entrada");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](58, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](59);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](60, "ion-col", 10)(61, "div", 11)(62, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](63, "Tr\u00E1fico Salida");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](64, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](65);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](66, "ion-col", 10)(67, "div", 11)(68, "div", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](69, "Errores");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](70, "div", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](71);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](72, "ion-card")(73, "ion-card-header")(74, "ion-card-title");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](75, "Gr\u00E1ficas");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](76, "ion-card-content")(77, "ion-item")(78, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](79, "Per\u00EDodo:");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](80, "ion-select", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](81, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("ionChange", function InterfaceDetailModalComponent_ng_container_10_Template_ion_select_ionChange_80_listener($event) {
      _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵrestoreView"](_r1);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_9__["ɵɵresetView"](ctx_r1.onGraphPeriodChange($event.detail.value));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](82, InterfaceDetailModalComponent_ng_container_10_ion_select_option_82_Template, 2, 2, "ion-select-option", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](83, "ion-card")(84, "ion-card-header")(85, "ion-card-title");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](86, "Tr\u00E1fico");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](87, "ion-card-content");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](88, InterfaceDetailModalComponent_ng_container_10_ng_container_88_Template, 3, 2, "ng-container", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](89, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](90, "ion-card")(91, "ion-card-header")(92, "ion-card-title");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](93, "Utilizaci\u00F3n");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](94, "ion-card-content");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](95, InterfaceDetailModalComponent_ng_container_10_ng_container_95_Template, 3, 2, "ng-container", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](96, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const summary_r6 = ctx.ngIf;
    const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](11);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", ctx_r1.interface == null ? null : ctx_r1.interface.ifName, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", (ctx_r1.interface == null ? null : ctx_r1.interface.ifAlias) || "N/A", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", (ctx_r1.interface == null ? null : ctx_r1.interface.ifDesc) || "N/A", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", (ctx_r1.interface == null ? null : ctx_r1.interface.type) || "N/A", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("color", ctx_r1.getStatusColor((ctx_r1.interface == null ? null : ctx_r1.interface.statusStr) || ""));
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", ctx_r1.interface == null ? null : ctx_r1.interface.statusStr, " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", (ctx_r1.interface == null ? null : ctx_r1.interface.inSpeed) || "N/A", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", (ctx_r1.interface == null ? null : ctx_r1.interface.outSpeed) || "N/A", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", (summary_r6 == null ? null : summary_r6.IntfIpaddress) || "N/A", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](12);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"]("", (summary_r6 == null ? null : summary_r6.Util) || "0", "%");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"]((summary_r6 == null ? null : summary_r6.inTraffic) || "0");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"]((summary_r6 == null ? null : summary_r6.outTraffic) || "0");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵclassProp"]("text-danger", (summary_r6 == null ? null : summary_r6.Errors) && (summary_r6 == null ? null : summary_r6.Errors) !== "0");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate1"](" ", (summary_r6 == null ? null : summary_r6.Errors) || "0", " ");
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](9);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("value", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](81, 19, ctx_r1.selectedGraphPeriod$));
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngForOf", ctx_r1.graphPeriods);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](89, 21, ctx_r1.graphTraffic$));
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](96, 23, ctx_r1.graphUtilization$));
  }
}
class InterfaceDetailModalComponent {
  constructor(modalCtrl, opmanagerApi) {
    this.modalCtrl = modalCtrl;
    this.opmanagerApi = opmanagerApi;
    this.loading$ = new rxjs__WEBPACK_IMPORTED_MODULE_3__.BehaviorSubject(true);
    this.summary$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.of)({});
    this.graphTraffic$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.of)({});
    this.graphUtilization$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.of)({});
    this.selectedGraphPeriod$ = new rxjs__WEBPACK_IMPORTED_MODULE_3__.BehaviorSubject('6');
    this.graphPeriods = [{
      value: '6',
      name: 'Today'
    }, {
      value: '7',
      name: 'Yesterday'
    }, {
      value: '4',
      name: 'Last 7 Days'
    }, {
      value: '5',
      name: 'Last 30 Days'
    }];
  }
  ngOnInit() {
    if (!this.interface) {
      this.dismiss();
      return;
    }
    const interfaceName = this.interface['interfaceName'] || this.interface['ifName'] || '';
    // Summary
    this.summary$ = this.opmanagerApi.getInterfaceSummary(interfaceName).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.tap)(() => this.loading$.next(false)), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(() => {
      this.loading$.next(false);
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.of)({});
    }));
    // Traffic graph
    this.graphTraffic$ = this.selectedGraphPeriod$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.switchMap)(period => this.opmanagerApi.getInterfaceGraphs(interfaceName, 'traffic', period).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(() => (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.of)({})))), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.startWith)({}));
    // Utilization graph
    this.graphUtilization$ = this.selectedGraphPeriod$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.switchMap)(period => this.opmanagerApi.getInterfaceGraphs(interfaceName, 'utilization', period).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_5__.catchError)(() => (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.of)({})))), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.startWith)({}));
  }
  dismiss() {
    this.modalCtrl.dismiss();
  }
  onGraphPeriodChange(period) {
    this.selectedGraphPeriod$.next(period);
  }
  getStatusColor(statusStr) {
    const status = (statusStr || '').toLowerCase();
    if (status.includes('critical')) return 'danger';
    if (status.includes('trouble')) return 'medium';
    if (status.includes('attention')) return 'warning';
    if (status.includes('down')) return 'danger';
    if (status.includes('clear')) return 'success';
    return 'light';
  }
  static #_ = _staticBlock = () => (this.ɵfac = function InterfaceDetailModalComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || InterfaceDetailModalComponent)(_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_2__.ModalController), _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdirectiveInject"](_services_opmanager_api_service__WEBPACK_IMPORTED_MODULE_11__.OpmanagerApiService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵdefineComponent"]({
    type: InterfaceDetailModalComponent,
    selectors: [["app-interface-detail-modal"]],
    inputs: {
      interface: "interface"
    },
    decls: 12,
    vars: 7,
    consts: [["slot", "end"], [3, "click"], ["slot", "icon-only", "name", "close"], ["class", "ion-text-center ion-padding-top", 4, "ngIf"], [4, "ngIf"], [1, "ion-text-center", "ion-padding-top"], ["name", "crescent"], ["size", "12", "size-md", "6"], [1, "info-row"], [3, "color"], ["size", "12", "size-sm", "6", "size-md", "3"], [1, "metric-box"], [1, "metric-label"], [1, "metric-value"], [3, "ionChange", "value"], [3, "value", 4, "ngFor", "ngForOf"], [3, "value"], ["class", "graph-placeholder", 4, "ngIf"], ["class", "ion-text-center ion-padding", 4, "ngIf"], [1, "graph-placeholder"], [1, "ion-text-center"], [1, "ion-text-center", "ion-padding"]],
    template: function InterfaceDetailModalComponent_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar")(2, "ion-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtext"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](4, "ion-buttons", 0)(5, "ion-button", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵlistener"]("click", function InterfaceDetailModalComponent_Template_ion_button_click_5_listener() {
          return ctx.dismiss();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelement"](6, "ion-icon", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementStart"](7, "ion-content");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](8, InterfaceDetailModalComponent_div_8_Template, 2, 0, "div", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](9, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtemplate"](10, InterfaceDetailModalComponent_ng_container_10_Template, 97, 25, "ng-container", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipe"](11, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵtextInterpolate"]((ctx.interface == null ? null : ctx.interface.ifName) || (ctx.interface == null ? null : ctx.interface.displayName));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](9, 3, ctx.loading$));
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_10__["ɵɵpipeBind1"](11, 5, ctx.summary$));
      }
    },
    dependencies: [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonicModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonBadge, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonCardTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonLabel, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonSelect, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonSelectOption, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonSpinner, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonToolbar, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.SelectValueAccessor, _angular_common__WEBPACK_IMPORTED_MODULE_0__.CommonModule, _angular_common__WEBPACK_IMPORTED_MODULE_0__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_0__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormsModule, _angular_common__WEBPACK_IMPORTED_MODULE_0__.AsyncPipe],
    styles: [".info-row[_ngcontent-%COMP%] {\n  margin-bottom: 12px;\n  font-size: 0.95em;\n  line-height: 1.5;\n}\n.info-row[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  display: block;\n  color: var(--ion-color-step-600, #666);\n  font-weight: 600;\n  margin-bottom: 4px;\n}\n\n.metric-box[_ngcontent-%COMP%] {\n  text-align: center;\n  padding: 16px;\n  background: var(--ion-color-step-50, #fafbfc);\n  border-radius: 8px;\n  border-left: 3px solid var(--ion-color-primary);\n}\n\n.metric-label[_ngcontent-%COMP%] {\n  font-size: 0.85em;\n  color: var(--ion-color-step-600, #999);\n  text-transform: uppercase;\n  margin-bottom: 8px;\n  font-weight: 500;\n}\n\n.metric-value[_ngcontent-%COMP%] {\n  font-size: 1.4em;\n  font-weight: bold;\n  color: var(--ion-color-dark, #222);\n}\n.metric-value.text-danger[_ngcontent-%COMP%] {\n  color: var(--ion-color-danger, #eb445a);\n}\n\n.graph-placeholder[_ngcontent-%COMP%] {\n  height: 200px;\n  background: var(--ion-color-step-100, #f0f0f0);\n  border-radius: 8px;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n  gap: 8px;\n  margin: 12px 0;\n}\n.graph-placeholder[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 0;\n  color: var(--ion-color-step-600, #999);\n}\n.graph-placeholder[_ngcontent-%COMP%]   small[_ngcontent-%COMP%] {\n  color: var(--ion-color-step-500, #aaa);\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvaW50ZXJmYWNlcy9pbnRlcmZhY2UtZGV0YWlsLW1vZGFsL2ludGVyZmFjZS1kZXRhaWwtbW9kYWwuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7QUFDRjtBQUNFO0VBQ0UsY0FBQTtFQUNBLHNDQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtBQUNKOztBQUdBO0VBQ0Usa0JBQUE7RUFDQSxhQUFBO0VBQ0EsNkNBQUE7RUFDQSxrQkFBQTtFQUNBLCtDQUFBO0FBQUY7O0FBR0E7RUFDRSxpQkFBQTtFQUNBLHNDQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FBQUY7O0FBR0E7RUFDRSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0NBQUE7QUFBRjtBQUVFO0VBQ0UsdUNBQUE7QUFBSjs7QUFJQTtFQUNFLGFBQUE7RUFDQSw4Q0FBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLFFBQUE7RUFDQSxjQUFBO0FBREY7QUFHRTtFQUNFLFNBQUE7RUFDQSxzQ0FBQTtBQURKO0FBSUU7RUFDRSxzQ0FBQTtBQUZKIiwic291cmNlc0NvbnRlbnQiOlsiLmluZm8tcm93IHtcbiAgbWFyZ2luLWJvdHRvbTogMTJweDtcbiAgZm9udC1zaXplOiAwLjk1ZW07XG4gIGxpbmUtaGVpZ2h0OiAxLjU7XG5cbiAgc3Ryb25nIHtcbiAgICBkaXNwbGF5OiBibG9jaztcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXN0ZXAtNjAwLCAjNjY2KTtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICAgIG1hcmdpbi1ib3R0b206IDRweDtcbiAgfVxufVxuXG4ubWV0cmljLWJveCB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcGFkZGluZzogMTZweDtcbiAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXN0ZXAtNTAsICNmYWZiZmMpO1xuICBib3JkZXItcmFkaXVzOiA4cHg7XG4gIGJvcmRlci1sZWZ0OiAzcHggc29saWQgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xufVxuXG4ubWV0cmljLWxhYmVsIHtcbiAgZm9udC1zaXplOiAwLjg1ZW07XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc3RlcC02MDAsICM5OTkpO1xuICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICBtYXJnaW4tYm90dG9tOiA4cHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG59XG5cbi5tZXRyaWMtdmFsdWUge1xuICBmb250LXNpemU6IDEuNGVtO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrLCAjMjIyKTtcbiAgXG4gICYudGV4dC1kYW5nZXIge1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFuZ2VyLCAjZWI0NDVhKTtcbiAgfVxufVxuXG4uZ3JhcGgtcGxhY2Vob2xkZXIge1xuICBoZWlnaHQ6IDIwMHB4O1xuICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3Itc3RlcC0xMDAsICNmMGYwZjApO1xuICBib3JkZXItcmFkaXVzOiA4cHg7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBnYXA6IDhweDtcbiAgbWFyZ2luOiAxMnB4IDA7XG5cbiAgcCB7XG4gICAgbWFyZ2luOiAwO1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc3RlcC02MDAsICM5OTkpO1xuICB9XG5cbiAgc21hbGwge1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc3RlcC01MDAsICNhYWEpO1xuICB9XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"],
    changeDetection: 0
  }));
}
_staticBlock();

/***/ }),

/***/ 8482:
/*!***********************************************!*\
  !*** ./src/app/interfaces/interfaces.page.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   InterfacesPage: () => (/* binding */ InterfacesPage)
/* harmony export */ });
/* harmony import */ var _Users_andresm_code_opmanager_ionic_dashboard_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 9204);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 3683);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 4456);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 1507);
/* harmony import */ var _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/cdk/scrolling */ 9975);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 5797);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 9999);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ 9452);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 1318);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ 271);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxjs/operators */ 3037);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxjs/operators */ 6647);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! rxjs/operators */ 8764);
/* harmony import */ var _interface_detail_modal_interface_detail_modal_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./interface-detail-modal/interface-detail-modal.component */ 3985);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @angular/core */ 4205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/core */ 2481);
/* harmony import */ var _services_opmanager_api_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../services/opmanager-api.service */ 5793);
/* harmony import */ var _services_dashboard_state_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../services/dashboard-state.service */ 3862);

var _staticBlock;













function InterfacesPage_ion_select_option_25_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "ion-select-option", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const severity_r1 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("value", severity_r1.value);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" ", severity_r1.name, " ");
  }
}
function InterfacesPage_ion_select_option_36_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "ion-select-option", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const type_r2 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("value", type_r2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" ", type_r2, " ");
  }
}
function InterfacesPage_div_42_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" ", ctx_r2.errorMessage, " ");
  }
}
function InterfacesPage_div_43_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](1, "ion-spinner", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }
}
function InterfacesPage_ng_container_45_ng_container_1_div_1_ion_icon_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](0, "ion-icon", 31);
  }
  if (rf & 2) {
    const sortConfig_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]().ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("name", sortConfig_r5.sortByType === "asc" ? "arrow-up-outline" : "arrow-down-outline");
  }
}
function InterfacesPage_ng_container_45_ng_container_1_div_1_ion_icon_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](0, "ion-icon", 31);
  }
  if (rf & 2) {
    const sortConfig_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]().ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("name", sortConfig_r5.sortByType === "asc" ? "arrow-up-outline" : "arrow-down-outline");
  }
}
function InterfacesPage_ng_container_45_ng_container_1_div_1_ion_icon_13_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](0, "ion-icon", 31);
  }
  if (rf & 2) {
    const sortConfig_r5 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]().ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("name", sortConfig_r5.sortByType === "asc" ? "arrow-up-outline" : "arrow-down-outline");
  }
}
function InterfacesPage_ng_container_45_ng_container_1_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 27)(1, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function InterfacesPage_ng_container_45_ng_container_1_div_1_Template_div_click_1_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r4);
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵresetView"](ctx_r2.sort("displayName"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](2, " Nombre ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](3, InterfacesPage_ng_container_45_ng_container_1_div_1_ion_icon_3_Template, 1, 1, "ion-icon", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](4, "div", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](5, "Alias");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](6, "div", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](7, "Descripci\u00F3n");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](8, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function InterfacesPage_ng_container_45_ng_container_1_div_1_Template_div_click_8_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r4);
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵresetView"](ctx_r2.sort("inSpeed"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](9, " Velocidad ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](10, InterfacesPage_ng_container_45_ng_container_1_div_1_ion_icon_10_Template, 1, 1, "ion-icon", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](11, "div", 28);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function InterfacesPage_ng_container_45_ng_container_1_div_1_Template_div_click_11_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r4);
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵresetView"](ctx_r2.sort("statusNum"));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](12, " Estado ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](13, InterfacesPage_ng_container_45_ng_container_1_div_1_ion_icon_13_Template, 1, 1, "ion-icon", 29);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const sortConfig_r5 = ctx.ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", sortConfig_r5.sortByColumn === "displayName");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", sortConfig_r5.sortByColumn === "inSpeed");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", sortConfig_r5.sortByColumn === "statusNum");
  }
}
function InterfacesPage_ng_container_45_ng_container_1_div_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 32);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function InterfacesPage_ng_container_45_ng_container_1_div_4_Template_div_click_0_listener() {
      const item_r7 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r6).$implicit;
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵresetView"](ctx_r2.openInterfaceDetails(item_r7));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](3, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](4);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](5, "div", 33);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](7, "div", 30);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](8);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](9, "div", 34);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const item_r7 = ctx.$implicit;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("title", item_r7.ifName || item_r7.displayName);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](item_r7.ifName || item_r7.displayName);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("title", item_r7.ifAlias);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](item_r7.ifAlias);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("title", item_r7.ifDesc);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](item_r7.ifDesc);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate"](item_r7.inSpeed);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngClass", ctx_r2.getStatusClass(item_r7));
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtextInterpolate1"](" ", item_r7.statusStr, " ");
  }
}
function InterfacesPage_ng_container_45_ng_container_1_div_5_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1, " No se encontraron interfaces con los filtros seleccionados. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }
}
function InterfacesPage_ng_container_45_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](1, InterfacesPage_ng_container_45_ng_container_1_div_1_Template, 14, 3, "div", 23);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](3, "cdk-virtual-scroll-viewport", 24);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](4, InterfacesPage_ng_container_45_ng_container_1_div_4_Template, 11, 9, "div", 25);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](5, InterfacesPage_ng_container_45_ng_container_1_div_5_Template, 2, 0, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](6, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const interfaces_r8 = ctx.ngIf;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](2, 3, ctx_r2.sort$));
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("cdkVirtualForOf", interfaces_r8);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", interfaces_r8.length === 0 && !_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](6, 5, ctx_r2.loading$));
  }
}
function InterfacesPage_ng_container_45_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](1, InterfacesPage_ng_container_45_ng_container_1_Template, 7, 7, "ng-container", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](2, 1, ctx_r2.interfaces$));
  }
}
function InterfacesPage_ng_container_47_ng_container_1_div_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 46);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function InterfacesPage_ng_container_47_ng_container_1_div_2_Template_div_click_0_listener() {
      const item_r10 = _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵrestoreView"](_r9).$implicit;
      const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](3);
      return _angular_core__WEBPACK_IMPORTED_MODULE_14__["ɵɵresetView"](ctx_r2.openInterfaceDetails(item_r10));
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const item_r10 = ctx.$implicit;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngClass", ctx_r2.getHeatmapStatusClass(item_r10))("title", (item_r10.ifName || item_r10.displayName) + " - " + item_r10.statusStr);
  }
}
function InterfacesPage_ng_container_47_ng_container_1_div_3_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "div", 35);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](1, " No se encontraron interfaces con los filtros seleccionados. ");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
  }
}
function InterfacesPage_ng_container_47_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](1, "div", 36);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](2, InterfacesPage_ng_container_47_ng_container_1_div_2_Template, 1, 2, "div", 37);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](3, InterfacesPage_ng_container_47_ng_container_1_div_3_Template, 2, 0, "div", 26);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](4, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](5, "ion-card", 38)(6, "ion-card-header")(7, "ion-card-title");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](8, "Leyenda");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](9, "ion-card-content")(10, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](11, "div", 40);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](12, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](13, "Clear (OK)");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](14, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](15, "div", 41);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](16, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](17, "Attention");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](18, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](19, "div", 42);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](20, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](21, "Trouble");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](22, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](23, "div", 43);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](24, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](25, "Critical");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](26, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](27, "div", 44);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](28, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](29, "Down");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](30, "div", 39);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](31, "div", 45);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](32, "span");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](33, "Unknown");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const interfaces_r11 = ctx.ngIf;
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngForOf", interfaces_r11);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", interfaces_r11.length === 0 && !_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](4, 2, ctx_r2.loading$));
  }
}
function InterfacesPage_ng_container_47_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerStart"](0);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](1, InterfacesPage_ng_container_47_ng_container_1_Template, 34, 4, "ng-container", 19);
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](2, "async");
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementContainerEnd"]();
  }
  if (rf & 2) {
    const ctx_r2 = _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](2, 1, ctx_r2.interfaces$));
  }
}
class InterfacesPage {
  constructor(opmanagerApi, dashboard, modalCtrl) {
    this.opmanagerApi = opmanagerApi;
    this.dashboard = dashboard;
    this.modalCtrl = modalCtrl;
    this.interfaces$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.of)([]);
    this.loading$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__.BehaviorSubject(true);
    this.errorMessage = null;
    this.interfaceTypes$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.of)([]);
    this.filters$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__.BehaviorSubject({});
    this.sort$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__.BehaviorSubject({
      sortByColumn: 'statusNum',
      sortByType: 'desc'
    });
    this.viewMode$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__.BehaviorSubject('table');
    // Input values for copy-paste functionality
    this.severityInputValue = '';
    this.typeInputValue = '';
    // Hardcoded based on API documentation
    this.severityOptions = [{
      value: '1',
      name: 'Critical'
    }, {
      value: '2',
      name: 'Trouble'
    }, {
      value: '3',
      name: 'Attention'
    }, {
      value: '4',
      name: 'Service Down'
    }, {
      value: '5',
      name: 'Clear'
    }, {
      value: '7',
      name: 'Unmanaged'
    }];
  }
  ngOnInit() {
    const trigger$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.combineLatest)([this.dashboard.selectedCustomer$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_10__.startWith)(null)), this.filters$, this.sort$]);
    this.interfaces$ = trigger$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.tap)(() => {
      this.loading$.next(true);
      this.errorMessage = null;
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_11__.switchMap)(([customer, filters, sort]) => {
      const params = {
        selCustomerID: customer ? customer.value : '-1',
        sortByColumn: sort.sortByColumn,
        sortByType: sort.sortByType
      };
      if (filters.severity) {
        params['severity'] = filters.severity;
      }
      if (filters.type) {
        params['type'] = filters.type;
      }
      return this.opmanagerApi.listInterfaces(params).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.catchError)(err => {
        console.error('Error fetching interfaces:', err);
        this.errorMessage = 'Error al cargar las interfaces. Verifique la conexión y la API Key.';
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_7__.of)([]);
      }));
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_12__.tap)(() => this.loading$.next(false)));
    // Derive interface types from the main data stream for the filter
    this.interfaceTypes$ = this.interfaces$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.map)(interfaces => {
      const types = new Set(interfaces.map(i => i['type']).filter(Boolean));
      return Array.from(types).sort();
    }));
  }
  onFilterChanged(filterName, value) {
    const currentFilters = this.filters$.value;
    this.filters$.next({
      ...currentFilters,
      [filterName]: value
    });
    // Update input values when select changes
    if (filterName === 'severity') {
      this.severityInputValue = value || '';
    } else if (filterName === 'type') {
      this.typeInputValue = value || '';
    }
  }
  onSeverityInputChange(ev) {
    const value = ev.detail.value?.trim() || '';
    this.severityInputValue = value;
    const currentFilters = this.filters$.value;
    this.filters$.next({
      ...currentFilters,
      severity: value
    });
  }
  onTypeInputChange(ev) {
    const value = ev.detail.value?.trim() || '';
    this.typeInputValue = value;
    const currentFilters = this.filters$.value;
    this.filters$.next({
      ...currentFilters,
      type: value
    });
  }
  sort(column) {
    const currentSort = this.sort$.value;
    let nextSortType = 'asc';
    if (currentSort.sortByColumn === column && currentSort.sortByType === 'asc') {
      nextSortType = 'desc';
    }
    this.sort$.next({
      sortByColumn: column,
      sortByType: nextSortType
    });
  }
  getStatusClass(item) {
    const status = (item['statusStr'] || '').toLowerCase();
    if (status.includes('critical')) return 'status-critical';
    if (status.includes('trouble')) return 'status-trouble';
    if (status.includes('attention')) return 'status-attention';
    if (status.includes('down')) return 'status-down';
    if (status.includes('clear')) return 'status-clear';
    return 'status-unknown';
  }
  toggleViewMode() {
    const current = this.viewMode$.value;
    this.viewMode$.next(current === 'table' ? 'heatmap' : 'table');
  }
  getHeatmapStatusClass(item) {
    const status = (item['statusStr'] || '').toLowerCase();
    if (status.includes('critical')) return 'heatmap-critical';
    if (status.includes('trouble')) return 'heatmap-trouble';
    if (status.includes('attention')) return 'heatmap-attention';
    if (status.includes('down')) return 'heatmap-down';
    if (status.includes('clear')) return 'heatmap-clear';
    return 'heatmap-unknown';
  }
  openInterfaceDetails(item) {
    var _this = this;
    return (0,_Users_andresm_code_opmanager_ionic_dashboard_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const modal = yield _this.modalCtrl.create({
        component: _interface_detail_modal_interface_detail_modal_component__WEBPACK_IMPORTED_MODULE_13__.InterfaceDetailModalComponent,
        componentProps: {
          interface: item
        }
      });
      yield modal.present();
    })();
  }
  exportToCsv() {
    // Get current interfaces from the observable
    this.interfaces$.pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.map)(interfaces => {
      if (!interfaces.length) {
        return;
      }
      const escape = value => {
        const str = value == null ? '' : String(value);
        if (/[,;"\n]/.test(str)) {
          return '"' + str.replace(/"/g, '""') + '"';
        }
        return str;
      };
      const rows = [];
      // Header row
      rows.push('Nombre;Alias;Descripción;Velocidad;Estado');
      interfaces.forEach(i => {
        rows.push([i['ifName'] || i['displayName'] || '', i['ifAlias'] || '', i['ifDesc'] || '', i['inSpeed'] || '', i['statusStr'] || ''].map(escape).join(';'));
      });
      const csvContent = rows.join('\n');
      const blob = new Blob([csvContent], {
        type: 'text/csv;charset=utf-8;'
      });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'opmanager_interfaces.csv');
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    })).subscribe();
  }
  static #_ = _staticBlock = () => (this.ɵfac = function InterfacesPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || InterfacesPage)(_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](_services_opmanager_api_service__WEBPACK_IMPORTED_MODULE_16__.OpmanagerApiService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](_services_dashboard_state_service__WEBPACK_IMPORTED_MODULE_17__.DashboardStateService), _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdirectiveInject"](_ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ModalController));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵdefineComponent"]({
    type: InterfacesPage,
    selectors: [["app-interfaces"]],
    decls: 49,
    vars: 29,
    consts: [[3, "translucent"], ["slot", "end"], ["title", "Cambiar vista", 3, "click"], ["slot", "icon-only", 3, "name"], [3, "fullscreen"], ["collapse", "condense"], ["size", "large"], ["size", "12", "size-md", "4"], ["position", "stacked", 1, "ion-padding-start"], ["placeholder", "Escribir o pegar...", 3, "ionInput", "value", "disabled"], [1, "ion-margin-top"], ["placeholder", "Todos", "interface", "popover", 3, "ionChange"], [3, "value"], [3, "value", 4, "ngFor", "ngForOf"], ["size", "12", "size-md", "4", 1, "ion-align-self-end"], ["expand", "block", "color", "success", 3, "click"], ["name", "download", "slot", "start"], ["class", "ion-padding ion-text-center", "style", "color: var(--ion-color-danger)", 4, "ngIf"], ["class", "ion-text-center ion-padding-top", 4, "ngIf"], [4, "ngIf"], [1, "ion-padding", "ion-text-center", 2, "color", "var(--ion-color-danger)"], [1, "ion-text-center", "ion-padding-top"], ["name", "crescent"], ["class", "header-row", 4, "ngIf"], ["itemSize", "50", 1, "ion-content-scroll-host"], ["class", "data-row clickable", 3, "click", 4, "cdkVirtualFor", "cdkVirtualForOf"], ["class", "ion-padding ion-text-center", 4, "ngIf"], [1, "header-row"], [1, "data-col", "sortable", 3, "click"], [3, "name", 4, "ngIf"], [1, "data-col"], [3, "name"], [1, "data-row", "clickable", 3, "click"], [1, "data-col", 3, "title"], [1, "data-col", 3, "ngClass"], [1, "ion-padding", "ion-text-center"], [1, "heatmap-container"], ["class", "heatmap-cell", 3, "ngClass", "title", "click", 4, "ngFor", "ngForOf"], [1, "ion-margin"], [1, "legend-item"], [1, "legend-color", "heatmap-clear"], [1, "legend-color", "heatmap-attention"], [1, "legend-color", "heatmap-trouble"], [1, "legend-color", "heatmap-critical"], [1, "legend-color", "heatmap-down"], [1, "legend-color", "heatmap-unknown"], [1, "heatmap-cell", 3, "click", "ngClass", "title"]],
    template: function InterfacesPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](0, "ion-header", 0)(1, "ion-toolbar")(2, "ion-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](3, " Interfaces ");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](4, "ion-buttons", 1)(5, "ion-button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function InterfacesPage_Template_ion_button_click_5_listener() {
          return ctx.toggleViewMode();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](6, "ion-icon", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](7, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](8, "ion-content", 4)(9, "ion-header", 5)(10, "ion-toolbar")(11, "ion-title", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](12, "Interfaces");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](13, "ion-grid")(14, "ion-row")(15, "ion-col", 7)(16, "ion-label", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](17, "Estado (Severity)");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](18, "ion-item")(19, "ion-input", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](20, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("ionInput", function InterfacesPage_Template_ion_input_ionInput_19_listener($event) {
          return ctx.onSeverityInputChange($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](21, "ion-item", 10)(22, "ion-select", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("ionChange", function InterfacesPage_Template_ion_select_ionChange_22_listener($event) {
          return ctx.onFilterChanged("severity", $event.detail.value);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](23, "ion-select-option", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](24, "Todos");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](25, InterfacesPage_ion_select_option_25_Template, 2, 2, "ion-select-option", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](26, "ion-col", 7)(27, "ion-label", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](28, "Tipo de Interfaz");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](29, "ion-item")(30, "ion-input", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](31, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("ionInput", function InterfacesPage_Template_ion_input_ionInput_30_listener($event) {
          return ctx.onTypeInputChange($event);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](32, "ion-item", 10)(33, "ion-select", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("ionChange", function InterfacesPage_Template_ion_select_ionChange_33_listener($event) {
          return ctx.onFilterChanged("type", $event.detail.value);
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](34, "ion-select-option", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](35, "Todos");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](36, InterfacesPage_ion_select_option_36_Template, 2, 2, "ion-select-option", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](37, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementStart"](38, "ion-col", 14)(39, "ion-button", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵlistener"]("click", function InterfacesPage_Template_ion_button_click_39_listener() {
          return ctx.exportToCsv();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelement"](40, "ion-icon", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtext"](41, " Exportar ");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]()()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](42, InterfacesPage_div_42_Template, 2, 1, "div", 17)(43, InterfacesPage_div_43_Template, 2, 0, "div", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](44, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](45, InterfacesPage_ng_container_45_Template, 3, 3, "ng-container", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](46, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵtemplate"](47, InterfacesPage_ng_container_47_Template, 3, 3, "ng-container", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipe"](48, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("translucent", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("name", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](7, 15, ctx.viewMode$) === "table" ? "grid-outline" : "list-outline");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("fullscreen", true);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("value", ctx.severityInputValue)("disabled", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](20, 17, ctx.loading$));
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("value", "");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngForOf", ctx.severityOptions);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](5);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("value", ctx.typeInputValue)("disabled", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](31, 19, ctx.loading$));
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](4);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("value", "");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](37, 21, ctx.interfaceTypes$));
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](6);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", ctx.errorMessage);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](44, 23, ctx.loading$));
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](46, 25, ctx.viewMode$) === "table");
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_15__["ɵɵpipeBind1"](48, 27, ctx.viewMode$) === "heatmap");
      }
    },
    dependencies: [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonicModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonButtons, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonCardTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonInput, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonLabel, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonSelect, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonSelectOption, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonSpinner, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonToolbar, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.SelectValueAccessor, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.TextValueAccessor, _angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormsModule, _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_4__.ScrollingModule, _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_4__.CdkFixedSizeVirtualScroll, _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_4__.CdkVirtualForOf, _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_4__.CdkVirtualScrollViewport, _angular_common__WEBPACK_IMPORTED_MODULE_1__.AsyncPipe],
    styles: [".header-row[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  font-weight: bold;\n  padding: 10px 16px;\n  border-bottom: 1px solid var(--ion-color-step-250, #d7d8da);\n  background-color: var(--ion-color-light, #f4f5f8);\n  font-size: 0.9em;\n}\n\n.data-row[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  padding: 10px 16px;\n  border-bottom: 1px solid var(--ion-color-step-150, #e9eaec);\n  font-size: 0.85em;\n}\n.data-row.clickable[_ngcontent-%COMP%] {\n  cursor: pointer;\n  transition: background-color 0.2s ease;\n}\n.data-row.clickable[_ngcontent-%COMP%]:hover {\n  background-color: var(--ion-color-step-100, #f0f0f0);\n}\n\n.data-col[_ngcontent-%COMP%] {\n  flex: 1;\n  padding: 0 8px;\n  text-align: left;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n\n.sortable[_ngcontent-%COMP%] {\n  cursor: pointer;\n  -webkit-user-select: none;\n          user-select: none;\n}\n.sortable[_ngcontent-%COMP%]:hover {\n  background-color: var(--ion-color-step-100, #f0f0f0);\n}\n.sortable[_ngcontent-%COMP%]   ion-icon[_ngcontent-%COMP%] {\n  vertical-align: middle;\n  margin-left: 4px;\n  font-size: 1.1em;\n}\n\n.status-clear[_ngcontent-%COMP%] {\n  color: var(--ion-color-success, #2dd36f);\n}\n\n.status-trouble[_ngcontent-%COMP%] {\n  color: var(--ion-color-warning, #ffc409);\n}\n\n.status-attention[_ngcontent-%COMP%] {\n  color: var(--ion-color-warning, #ffc409);\n}\n\n.status-critical[_ngcontent-%COMP%] {\n  color: var(--ion-color-danger, #eb445a);\n}\n\n.status-down[_ngcontent-%COMP%] {\n  color: var(--ion-color-danger, #eb445a);\n}\n\n.status-unknown[_ngcontent-%COMP%] {\n  color: var(--ion-color-medium, #92949c);\n}\n\ncdk-virtual-scroll-viewport[_ngcontent-%COMP%] {\n  height: calc(100vh - 200px); \n\n}\n\n.heatmap-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-wrap: wrap;\n  gap: 8px;\n  padding: 16px;\n  background-color: var(--ion-color-light, #f4f5f8);\n}\n\n.heatmap-cell[_ngcontent-%COMP%] {\n  width: 30px;\n  height: 30px;\n  border-radius: 4px;\n  cursor: pointer;\n  transition: all 0.2s ease;\n  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);\n}\n.heatmap-cell[_ngcontent-%COMP%]:hover {\n  transform: scale(1.2);\n  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);\n}\n\n.heatmap-clear[_ngcontent-%COMP%] {\n  background-color: var(--ion-color-success, #2dd36f);\n}\n\n.heatmap-attention[_ngcontent-%COMP%] {\n  background-color: var(--ion-color-warning, #ffc409);\n}\n\n.heatmap-trouble[_ngcontent-%COMP%] {\n  background-color: var(--ion-color-medium, #92949c);\n}\n\n.heatmap-critical[_ngcontent-%COMP%] {\n  background-color: var(--ion-color-danger, #eb445a);\n}\n\n.heatmap-down[_ngcontent-%COMP%] {\n  background-color: #8b0000;\n} \n\n.heatmap-unknown[_ngcontent-%COMP%] {\n  background-color: var(--ion-color-light, #d0d0d0);\n}\n\n.legend-item[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  margin-bottom: 8px;\n}\n.legend-item[_ngcontent-%COMP%]   .legend-color[_ngcontent-%COMP%] {\n  width: 20px;\n  height: 20px;\n  border-radius: 3px;\n  margin-right: 12px;\n}\n.legend-item[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-size: 0.9em;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvaW50ZXJmYWNlcy9pbnRlcmZhY2VzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGFBQUE7RUFDQSw4QkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSwyREFBQTtFQUNBLGlEQUFBO0VBQ0EsZ0JBQUE7QUFDRjs7QUFFQTtFQUNFLGFBQUE7RUFDQSw4QkFBQTtFQUNBLGtCQUFBO0VBQ0EsMkRBQUE7RUFDQSxpQkFBQTtBQUNGO0FBQ0U7RUFDRSxlQUFBO0VBQ0Esc0NBQUE7QUFDSjtBQUNJO0VBQ0Usb0RBQUE7QUFDTjs7QUFJQTtFQUNFLE9BQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsdUJBQUE7QUFERjs7QUFJQTtFQUNFLGVBQUE7RUFDQSx5QkFBQTtVQUFBLGlCQUFBO0FBREY7QUFFRTtFQUNFLG9EQUFBO0FBQUo7QUFFRTtFQUNFLHNCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtBQUFKOztBQUlBO0VBQWdCLHdDQUFBO0FBQWhCOztBQUNBO0VBQWtCLHdDQUFBO0FBR2xCOztBQUZBO0VBQW9CLHdDQUFBO0FBTXBCOztBQUxBO0VBQW1CLHVDQUFBO0FBU25COztBQVJBO0VBQWUsdUNBQUE7QUFZZjs7QUFYQTtFQUFrQix1Q0FBQTtBQWVsQjs7QUFiQTtFQUNFLDJCQUFBLEVBQUEsMENBQUE7QUFnQkY7O0FBYkE7RUFDRSxhQUFBO0VBQ0EsZUFBQTtFQUNBLFFBQUE7RUFDQSxhQUFBO0VBQ0EsaURBQUE7QUFnQkY7O0FBYkE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLHlCQUFBO0VBQ0Esd0NBQUE7QUFnQkY7QUFkRTtFQUNFLHFCQUFBO0VBQ0Esd0NBQUE7QUFnQko7O0FBWkE7RUFBaUIsbURBQUE7QUFnQmpCOztBQWZBO0VBQXFCLG1EQUFBO0FBbUJyQjs7QUFsQkE7RUFBbUIsa0RBQUE7QUFzQm5COztBQXJCQTtFQUFvQixrREFBQTtBQXlCcEI7O0FBeEJBO0VBQWdCLHlCQUFBO0FBNEJoQixFQTVCNkMsOEJBQUE7QUFDN0M7RUFBbUIsaURBQUE7QUE4Qm5COztBQTVCQTtFQUNFLGFBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0FBK0JGO0FBN0JFO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FBK0JKO0FBNUJFO0VBQ0UsZ0JBQUE7QUE4QkoiLCJzb3VyY2VzQ29udGVudCI6WyIuaGVhZGVyLXJvdyB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIHBhZGRpbmc6IDEwcHggMTZweDtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1zdGVwLTI1MCwgI2Q3ZDhkYSk7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodCwgI2Y0ZjVmOCk7XG4gIGZvbnQtc2l6ZTogMC45ZW07XG59XG5cbi5kYXRhLXJvdyB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgcGFkZGluZzogMTBweCAxNnB4O1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgdmFyKC0taW9uLWNvbG9yLXN0ZXAtMTUwLCAjZTllYWVjKTtcbiAgZm9udC1zaXplOiAwLjg1ZW07XG5cbiAgJi5jbGlja2FibGUge1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICB0cmFuc2l0aW9uOiBiYWNrZ3JvdW5kLWNvbG9yIDAuMnMgZWFzZTtcblxuICAgICY6aG92ZXIge1xuICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXN0ZXAtMTAwLCAjZjBmMGYwKTtcbiAgICB9XG4gIH1cbn1cblxuLmRhdGEtY29sIHtcbiAgZmxleDogMTtcbiAgcGFkZGluZzogMCA4cHg7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xufVxuXG4uc29ydGFibGUge1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIHVzZXItc2VsZWN0OiBub25lO1xuICAmOmhvdmVyIHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3Itc3RlcC0xMDAsICNmMGYwZjApO1xuICB9XG4gIGlvbi1pY29uIHtcbiAgICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICAgIG1hcmdpbi1sZWZ0OiA0cHg7XG4gICAgZm9udC1zaXplOiAxLjFlbTtcbiAgfVxufVxuXG4uc3RhdHVzLWNsZWFyIHsgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zdWNjZXNzLCAjMmRkMzZmKTsgfVxuLnN0YXR1cy10cm91YmxlIHsgY29sb3I6IHZhcigtLWlvbi1jb2xvci13YXJuaW5nLCAjZmZjNDA5KTsgfVxuLnN0YXR1cy1hdHRlbnRpb24geyBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXdhcm5pbmcsICNmZmM0MDkpOyB9XG4uc3RhdHVzLWNyaXRpY2FsIHsgY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYW5nZXIsICNlYjQ0NWEpOyB9XG4uc3RhdHVzLWRvd24geyBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhbmdlciwgI2ViNDQ1YSk7IH1cbi5zdGF0dXMtdW5rbm93biB7IGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtLCAjOTI5NDljKTsgfVxuXG5jZGstdmlydHVhbC1zY3JvbGwtdmlld3BvcnQge1xuICBoZWlnaHQ6IGNhbGMoMTAwdmggLSAyMDBweCk7IC8qIEFkanVzdCBhcyBuZWVkZWQgYmFzZWQgb24geW91ciBsYXlvdXQgKi9cbn1cblxuLmhlYXRtYXAtY29udGFpbmVyIHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC13cmFwOiB3cmFwO1xuICBnYXA6IDhweDtcbiAgcGFkZGluZzogMTZweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0LCAjZjRmNWY4KTtcbn1cblxuLmhlYXRtYXAtY2VsbCB7XG4gIHdpZHRoOiAzMHB4O1xuICBoZWlnaHQ6IDMwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDRweDtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICB0cmFuc2l0aW9uOiBhbGwgMC4ycyBlYXNlO1xuICBib3gtc2hhZG93OiAwIDFweCAzcHggcmdiYSgwLCAwLCAwLCAwLjEpO1xuXG4gICY6aG92ZXIge1xuICAgIHRyYW5zZm9ybTogc2NhbGUoMS4yKTtcbiAgICBib3gtc2hhZG93OiAwIDJweCA4cHggcmdiYSgwLCAwLCAwLCAwLjIpO1xuICB9XG59XG5cbi5oZWF0bWFwLWNsZWFyIHsgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXN1Y2Nlc3MsICMyZGQzNmYpOyB9XG4uaGVhdG1hcC1hdHRlbnRpb24geyBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3Itd2FybmluZywgI2ZmYzQwOSk7IH1cbi5oZWF0bWFwLXRyb3VibGUgeyBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtLCAjOTI5NDljKTsgfVxuLmhlYXRtYXAtY3JpdGljYWwgeyBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFuZ2VyLCAjZWI0NDVhKTsgfVxuLmhlYXRtYXAtZG93biB7IGJhY2tncm91bmQtY29sb3I6ICM4YjAwMDA7IH0gLyogRGFyayByZWQgZm9yIFwiZG93blwiIHN0YXRlICovXG4uaGVhdG1hcC11bmtub3duIHsgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0LCAjZDBkMGQwKTsgfVxuXG4ubGVnZW5kLWl0ZW0ge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBtYXJnaW4tYm90dG9tOiA4cHg7XG5cbiAgLmxlZ2VuZC1jb2xvciB7XG4gICAgd2lkdGg6IDIwcHg7XG4gICAgaGVpZ2h0OiAyMHB4O1xuICAgIGJvcmRlci1yYWRpdXM6IDNweDtcbiAgICBtYXJnaW4tcmlnaHQ6IDEycHg7XG4gIH1cblxuICBzcGFuIHtcbiAgICBmb250LXNpemU6IDAuOWVtO1xuICB9XG59XG5cbiJdLCJzb3VyY2VSb290IjoiIn0= */"],
    changeDetection: 0
  }));
}
_staticBlock();

/***/ })

}]);
//# sourceMappingURL=src_app_interfaces_interfaces_module_ts.js.map