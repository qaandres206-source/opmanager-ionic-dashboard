"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_settings_settings_module_ts"],{

/***/ 4670:
/*!*****************************************************!*\
  !*** ./src/app/settings/settings-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SettingsPageRoutingModule: () => (/* binding */ SettingsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ 4487);
/* harmony import */ var _settings_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./settings.page */ 7984);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2481);
var _staticBlock;




const routes = [{
  path: '',
  component: _settings_page__WEBPACK_IMPORTED_MODULE_1__.SettingsPage
}];
class SettingsPageRoutingModule {
  static #_ = _staticBlock = () => (this.ɵfac = function SettingsPageRoutingModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || SettingsPageRoutingModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
    type: SettingsPageRoutingModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule.forChild(routes), _angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](SettingsPageRoutingModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule],
    exports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule]
  });
})();

/***/ }),

/***/ 7984:
/*!*******************************************!*\
  !*** ./src/app/settings/settings.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SettingsPage: () => (/* binding */ SettingsPage)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ 3683);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ 4456);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 1507);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 4487);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2481);
/* harmony import */ var _services_dashboard_state_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/dashboard-state.service */ 3862);
/* harmony import */ var _services_opmanager_api_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/opmanager-api.service */ 5793);
var _staticBlock;










class SettingsPage {
  constructor(dashboard, api) {
    this.dashboard = dashboard;
    this.api = api;
    this.apiKey = '';
    this.refreshIntervalSeconds = 30;
    this.apiKey = this.api.apiKey ?? '';
  }
  onSaveApiKey() {
    const key = this.apiKey.trim();
    this.dashboard.setApiKey(key || null);
  }
  onTestConnection() {
    this.dashboard.authenticate().subscribe();
  }
  onSaveSettings() {
    // For now we just keep refreshIntervalSeconds in the component; you can wire auto-refresh later.
  }
  static #_ = _staticBlock = () => (this.ɵfac = function SettingsPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || SettingsPage)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_services_dashboard_state_service__WEBPACK_IMPORTED_MODULE_5__.DashboardStateService), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_services_opmanager_api_service__WEBPACK_IMPORTED_MODULE_6__.OpmanagerApiService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
    type: SettingsPage,
    selectors: [["app-settings"]],
    decls: 83,
    vars: 2,
    consts: [[1, "ion-padding"], ["position", "stacked"], ["type", "password", 3, "ngModelChange", "ngModel"], ["expand", "block", "color", "primary", 1, "ion-margin-top", 3, "click"], ["name", "save", "slot", "start"], ["expand", "block", 3, "click"], ["name", "cloud-outline", "slot", "start"], ["type", "number", 3, "ngModelChange", "ngModel"], ["expand", "block", 1, "ion-margin-top", 3, "click"], ["routerLink", "/api/alarms-all"], ["routerLink", "/api/alarms-active"], ["routerLink", "/api/alarms-severity-1"], ["routerLink", "/api/alarms-severity-4"], ["routerLink", "/api/devices-all"], ["routerLink", "/api/devices-firewall"], ["routerLink", "/api/devices-server"], ["routerLink", "/api/devices-severity-7"], ["routerLink", "/api/devices-severity-4"], ["routerLink", "/api/devices-severity-1"], ["routerLink", "/api/monitors-associated"], ["routerLink", "/api/monitors-performance"], ["routerLink", "/api/top-devices-interface-down"], ["routerLink", "/api/top-devices-device-down"], ["routerLink", "/api/ping-device"], ["routerLink", "/api/trace-device"], ["routerLink", "/api/events-all"], ["routerLink", "/api/events-device-down"], ["routerLink", "/api/events-interface-down"]],
    template: function SettingsPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar")(2, "ion-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "Configuraci\u00F3n");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "ion-content", 0)(5, "ion-card")(6, "ion-card-header")(7, "ion-card-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](8, "API Key de OpManager");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "ion-card-subtitle");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](10, " Ingresa tu API Key para conectarte a la API de OpManager (se guarda localmente) ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "ion-card-content")(12, "ion-item")(13, "ion-label", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](14, "API Key");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](15, "ion-input", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtwoWayListener"]("ngModelChange", function SettingsPage_Template_ion_input_ngModelChange_15_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtwoWayBindingSet"](ctx.apiKey, $event) || (ctx.apiKey = $event);
          return $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](16, "ion-button", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function SettingsPage_Template_ion_button_click_16_listener() {
          return ctx.onSaveApiKey();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](17, "ion-icon", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](18, " Guardar API Key ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](19, "ion-card")(20, "ion-card-header")(21, "ion-card-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](22, "Estado de Conexi\u00F3n");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](23, "ion-card-content")(24, "ion-button", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function SettingsPage_Template_ion_button_click_24_listener() {
          return ctx.onTestConnection();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](25, "ion-icon", 6);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](26, " Probar Conexi\u00F3n ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](27, "ion-card")(28, "ion-card-header")(29, "ion-card-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](30, "Configuraci\u00F3n de Actualizaci\u00F3n");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](31, "ion-card-content")(32, "ion-item")(33, "ion-label", 1);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](34, "Intervalo de actualizaci\u00F3n (segundos)");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](35, "ion-input", 7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtwoWayListener"]("ngModelChange", function SettingsPage_Template_ion_input_ngModelChange_35_listener($event) {
          _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtwoWayBindingSet"](ctx.refreshIntervalSeconds, $event) || (ctx.refreshIntervalSeconds = $event);
          return $event;
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](36, "ion-button", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function SettingsPage_Template_ion_button_click_36_listener() {
          return ctx.onSaveSettings();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](37, "ion-icon", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](38, " Guardar Configuraci\u00F3n ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](39, "ion-card")(40, "ion-card-header")(41, "ion-card-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](42, "Explorador de Endpoints");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](43, "ion-card-content")(44, "ion-list")(45, "ion-item", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](46, "Alertas - Todas");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](47, "ion-item", 10);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](48, "Alertas - Activas");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](49, "ion-item", 11);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](50, "Alertas - Severidad 1");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](51, "ion-item", 12);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](52, "Alertas - Severidad 4");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](53, "ion-item", 13);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](54, "Dispositivos - Todos");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](55, "ion-item", 14);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](56, "Dispositivos - Firewall (cliente 902)");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](57, "ion-item", 15);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](58, "Dispositivos - Servers");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](59, "ion-item", 16);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](60, "Dispositivos - Severidad 7");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](61, "ion-item", 17);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](62, "Dispositivos - Severidad 4");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](63, "ion-item", 18);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](64, "Dispositivos - Severidad 1");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](65, "ion-item", 19);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](66, "Monitores asociados (10.47.5.5.130000000001)");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](67, "ion-item", 20);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](68, "Monitores de rendimiento (10.1.19.30.160000000001)");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](69, "ion-item", 21);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](70, "Top dispositivos - Interface Down");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](71, "ion-item", 22);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](72, "Top dispositivos - Device Down");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](73, "ion-item", 23);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](74, "Ping device 10.47.5.5.130000000001");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](75, "ion-item", 24);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](76, "Trace route 10.47.5.5.130000000001");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](77, "ion-item", 25);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](78, "Eventos - Todos");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](79, "ion-item", 26);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](80, "Eventos - Device Down");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](81, "ion-item", 27);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](82, "Eventos - Interface Down");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](15);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtwoWayProperty"]("ngModel", ctx.apiKey);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](20);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtwoWayProperty"]("ngModel", ctx.refreshIntervalSeconds);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_0__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormsModule, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.NgControlStatus, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.NgModel, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonicModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonCardSubtitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonCardTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonInput, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonLabel, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonList, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonToolbar, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.NumericValueAccessor, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.TextValueAccessor, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.RouterLinkDelegate, _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule, _angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterLink],
    styles: ["\n\n[_nghost-%COMP%] {\n  display: block;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc2V0dGluZ3Mvc2V0dGluZ3MucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLHFEQUFBO0FBQ0E7RUFBUSxjQUFBO0FBRVIiLCJzb3VyY2VzQ29udGVudCI6WyIvKiBTdHlsZXMgZm9yIFNldHRpbmdzIHBhZ2UgLSBpbnRlbnRpb25hbGx5IG1pbmltYWwgKi9cbjpob3N0IHsgZGlzcGxheTogYmxvY2s7IH1cbiJdLCJzb3VyY2VSb290IjoiIn0= */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 8951:
/*!*********************************************!*\
  !*** ./src/app/settings/settings.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SettingsPageModule: () => (/* binding */ SettingsPageModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ 3683);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ 4456);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 1507);
/* harmony import */ var _settings_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./settings-routing.module */ 4670);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 4205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2481);
var _staticBlock;





class SettingsPageModule {
  static #_ = _staticBlock = () => (this.ɵfac = function SettingsPageModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || SettingsPageModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineNgModule"]({
    type: SettingsPageModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjector"]({
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonicModule, _settings_routing_module__WEBPACK_IMPORTED_MODULE_3__.SettingsPageRoutingModule]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsetNgModuleScope"](SettingsPageModule, {
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_1__.FormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.IonicModule, _settings_routing_module__WEBPACK_IMPORTED_MODULE_3__.SettingsPageRoutingModule]
  });
})();

/***/ })

}]);
//# sourceMappingURL=src_app_settings_settings_module_ts.js.map