"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_api-explorer_api-explorer_module_ts"],{

/***/ 4353:
/*!*****************************************************!*\
  !*** ./src/app/api-explorer/api-explorer.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ApiExplorerPageModule: () => (/* binding */ ApiExplorerPageModule)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ 3683);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 1507);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 4487);
/* harmony import */ var _api_explorer_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./api-explorer.page */ 7578);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 4205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2481);
var _staticBlock;






const routes = [{
  path: '',
  component: _api_explorer_page__WEBPACK_IMPORTED_MODULE_3__.ApiExplorerPage
}];
class ApiExplorerPageModule {
  static #_ = _staticBlock = () => (this.ɵfac = function ApiExplorerPageModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || ApiExplorerPageModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineNgModule"]({
    type: ApiExplorerPageModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineInjector"]({
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__.CommonModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonicModule, _angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule.forChild(routes)]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵsetNgModuleScope"](ApiExplorerPageModule, {
    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_0__.CommonModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonicModule, _angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule]
  });
})();

/***/ }),

/***/ 7578:
/*!***************************************************!*\
  !*** ./src/app/api-explorer/api-explorer.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ApiExplorerPage: () => (/* binding */ ApiExplorerPage)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ 4487);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ 3683);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ 4456);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 1507);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2481);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 5422);
/* harmony import */ var _services_opmanager_api_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/opmanager-api.service */ 5793);
var _staticBlock;









function ApiExplorerPage_ion_spinner_8_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](0, "ion-spinner");
  }
}
function ApiExplorerPage_ion_text_9_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-text", 4);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](1);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](ctx_r0.error);
  }
}
function ApiExplorerPage_ion_card_10_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-card")(1, "ion-card-content")(2, "pre");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](4, "json");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const ctx_r0 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](4, 1, ctx_r0.data));
  }
}
class ApiExplorerPage {
  constructor(route, api) {
    this.route = route;
    this.api = api;
    this.id = null;
    this.loading = false;
    this.data = null;
    this.error = null;
  }
  ngOnInit() {
    this.id = this.route.snapshot.paramMap.get('id');
    if (this.id) {
      this.callEndpoint(this.id);
    }
  }
  callEndpoint(id) {
    this.loading = true;
    this.error = null;
    this.data = null;
    let obs$;
    switch (id) {
      case 'alarms-all':
        obs$ = this.api.getAlarms();
        break;
      case 'alarms-active':
        obs$ = this.api.getAlarms({
          alertType: 'ActiveAlarms'
        });
        break;
      case 'alarms-severity-1':
        obs$ = this.api.getAlarms({
          severity: 1
        });
        break;
      case 'alarms-severity-4':
        obs$ = this.api.getAlarms({
          severity: 4
        });
        break;
      case 'devices-all':
        obs$ = this.api.getDevices();
        break;
      case 'devices-firewall':
        obs$ = this.api.getDevices({
          selCustomerID: 902,
          category: 'Firewall'
        });
        break;
      case 'devices-server':
        obs$ = this.api.getDevices({
          category: 'Server'
        });
        break;
      case 'devices-severity-7':
        obs$ = this.api.getDevices({
          severity: 7
        });
        break;
      case 'devices-severity-4':
        obs$ = this.api.getDevices({
          severity: 4
        });
        break;
      case 'devices-severity-1':
        obs$ = this.api.getDevices({
          severity: 1
        });
        break;
      case 'monitors-associated':
        obs$ = this.api.getDeviceAssociatedMonitors('10.47.5.5.130000000001');
        break;
      case 'monitors-performance':
        obs$ = this.api.getPerformanceMonitors('10.1.19.30.160000000001', 'Server', 'Linux');
        break;
      case 'top-devices-interface-down':
        obs$ = this.api.getTopDevicesByAlarms('Interface Down');
        break;
      case 'top-devices-device-down':
        obs$ = this.api.getTopDevicesByAlarms('Device Down');
        break;
      case 'ping-device':
        obs$ = this.api.postPingResponse('10.47.5.5.130000000001');
        break;
      case 'trace-device':
        obs$ = this.api.postTraceResponse('10.47.5.5.130000000001');
        break;
      case 'events-all':
        obs$ = this.api.getEvents();
        break;
      case 'events-device-down':
        obs$ = this.api.getEvents({
          eventType: 'Device Down'
        });
        break;
      case 'events-interface-down':
        obs$ = this.api.getEvents({
          eventType: 'Interface Down'
        });
        break;
      default:
        this.error = 'Endpoint no reconocido';
        this.loading = false;
        return;
    }
    obs$.subscribe({
      next: res => {
        this.data = res;
        this.loading = false;
      },
      error: err => {
        this.error = String(err);
        this.loading = false;
      }
    });
  }
  static #_ = _staticBlock = () => (this.ɵfac = function ApiExplorerPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || ApiExplorerPage)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute), _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_services_opmanager_api_service__WEBPACK_IMPORTED_MODULE_6__.OpmanagerApiService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
    type: ApiExplorerPage,
    selectors: [["app-api-explorer"]],
    decls: 11,
    vars: 4,
    consts: [[1, "ion-padding"], ["color", "medium"], [4, "ngIf"], ["color", "danger", 4, "ngIf"], ["color", "danger"]],
    template: function ApiExplorerPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar")(2, "ion-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "Explorador de API");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "ion-content", 0)(5, "ion-text", 1)(6, "p");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](8, ApiExplorerPage_ion_spinner_8_Template, 1, 0, "ion-spinner", 2)(9, ApiExplorerPage_ion_text_9_Template, 2, 1, "ion-text", 3)(10, ApiExplorerPage_ion_card_10_Template, 5, 3, "ion-card", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](7);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"]("Mostrando datos para: ", ctx.id);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.loading);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.error);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", ctx.data && !ctx.loading);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_1__.CommonModule, _angular_common__WEBPACK_IMPORTED_MODULE_1__.NgIf, _angular_forms__WEBPACK_IMPORTED_MODULE_2__.FormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonicModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonSpinner, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonText, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.IonToolbar, _angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule, _angular_common__WEBPACK_IMPORTED_MODULE_1__.JsonPipe],
    styles: ["\n\n[_nghost-%COMP%] {\n  display: block;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvYXBpLWV4cGxvcmVyL2FwaS1leHBsb3Jlci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsb0RBQUE7QUFDQTtFQUFRLGNBQUE7QUFFUiIsInNvdXJjZXNDb250ZW50IjpbIi8qIFN0eWxlcyBmb3IgQXBpIEV4cGxvcmVyIC0gaW50ZW50aW9uYWxseSBtaW5pbWFsICovXG46aG9zdCB7IGRpc3BsYXk6IGJsb2NrOyB9XG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  }));
}
_staticBlock();

/***/ })

}]);
//# sourceMappingURL=src_app_api-explorer_api-explorer_module_ts.js.map