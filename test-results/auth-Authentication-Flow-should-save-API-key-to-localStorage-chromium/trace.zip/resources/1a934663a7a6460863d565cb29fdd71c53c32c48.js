"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_sre-audit_sre-audit_module_ts"],{

/***/ 1543:
/*!***********************************************!*\
  !*** ./src/app/sre-audit/sre-audit.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SreAuditPageModule: () => (/* binding */ SreAuditPageModule)
/* harmony export */ });
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/router */ 4487);
/* harmony import */ var _sre_audit_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sre-audit.page */ 1904);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 4205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2481);
var _staticBlock;




const routes = [{
  path: '',
  component: _sre_audit_page__WEBPACK_IMPORTED_MODULE_1__.SreAuditPage
}];
class SreAuditPageModule {
  static #_ = _staticBlock = () => (this.ɵfac = function SreAuditPageModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || SreAuditPageModule)();
  }, this.ɵmod = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵdefineNgModule"]({
    type: SreAuditPageModule
  }), this.ɵinj = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjector"]({
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule.forChild(routes), _sre_audit_page__WEBPACK_IMPORTED_MODULE_1__.SreAuditPage]
  }));
}
_staticBlock();
(function () {
  (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵsetNgModuleScope"](SreAuditPageModule, {
    imports: [_angular_router__WEBPACK_IMPORTED_MODULE_0__.RouterModule, _sre_audit_page__WEBPACK_IMPORTED_MODULE_1__.SreAuditPage]
  });
})();

/***/ }),

/***/ 1904:
/*!*********************************************!*\
  !*** ./src/app/sre-audit/sre-audit.page.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SreAuditPage: () => (/* binding */ SreAuditPage)
/* harmony export */ });
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common */ 3683);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 1507);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 4487);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 4205);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2481);
/* harmony import */ var _services_sre_audit_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/sre-audit.service */ 2020);
var _staticBlock;







const _c0 = (a0, a1, a2) => ({
  "log-info": a0,
  "log-warn": a1,
  "log-error": a2
});
function SreAuditPage_div_19_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 10);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](1, "ion-spinner", 11);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](2, "p");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "Procesando\u2026 revisa el monitor de logs.");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
}
function SreAuditPage_div_21_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 10)(1, "ion-text", 12);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2, "Proceso finalizado");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
}
function SreAuditPage_ion_card_24_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵgetCurrentView"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-card")(1, "ion-card-header")(2, "ion-card-title");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "Resumen Ejecutivo");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "ion-card-content")(5, "ion-list")(6, "ion-item")(7, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](8, "Total dispositivos");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](9, "ion-note", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](11, "ion-item")(12, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](13, "Total interfaces");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](14, "ion-note", 13);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](15);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](16, "ion-item")(17, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](18, "Sin monitoreo");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](19, "ion-note", 14);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](20);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](21, "ion-item")(22, "ion-label");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](23, "Interfaces DOWN");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](24, "ion-note", 15);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](25);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](26, "ion-button", 16);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function SreAuditPage_ion_card_24_Template_ion_button_click_26_listener() {
      _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵrestoreView"](_r1);
      const ctx_r1 = _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵnextContext"]();
      return _angular_core__WEBPACK_IMPORTED_MODULE_3__["ɵɵresetView"](ctx_r1.exportToCsv());
    });
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelement"](27, "ion-icon", 17);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](28, " Exportar a Excel (CSV) ");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const summary_r3 = ctx.ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](10);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](summary_r3.devices.length);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](summary_r3.totalInterfaces);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](summary_r3.totalUnmonitored);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](summary_r3.totalDown);
  }
}
function SreAuditPage_ion_card_26_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-card")(1, "ion-card-header")(2, "ion-card-title");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "Error");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "ion-card-content")(5, "ion-text", 18);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
  }
  if (rf & 2) {
    const error_r4 = ctx.ngIf;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](6);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](error_r4);
  }
}
function SreAuditPage_div_37_Template(rf, ctx) {
  if (rf & 1) {
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "div", 19)(1, "span", 20);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](3, "date");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "span", 21);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](5);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](6, "span", 22);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](7);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
  }
  if (rf & 2) {
    const log_r5 = ctx.$implicit;
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngClass", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpureFunction3"](7, _c0, log_r5.level === "info", log_r5.level === "warn", log_r5.level === "error"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind2"](3, 4, log_r5.timestamp, "HH:mm:ss"));
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate1"]("[", log_r5.level.toUpperCase(), "]");
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
    _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtextInterpolate"](log_r5.message);
  }
}
class SreAuditPage {
  constructor(audit) {
    this.audit = audit;
    this.logs$ = this.audit.logs$;
    this.running$ = this.audit.running$;
    this.summary$ = this.audit.summary$;
    this.error$ = this.audit.error$;
    this.mode$ = this.audit.mode$;
  }
  runQuick() {
    this.audit.startQuickMode().subscribe();
  }
  runFull() {
    this.audit.startFullProcess().subscribe();
  }
  exportToCsv() {
    const summary = this.audit.summary$.value;
    if (!summary) {
      // Nothing to export yet
      return;
    }
    const escape = value => {
      const str = value == null ? '' : String(value);
      // Surround with quotes if it contains separators or quotes
      if (/[,;"\n]/.test(str)) {
        return '"' + str.replace(/"/g, '""') + '"';
      }
      return str;
    };
    const rows = [];
    // Executive summary section
    rows.push('Resumen Ejecutivo');
    rows.push('Total dispositivos;Total interfaces;Sin monitoreo;Interfaces DOWN');
    rows.push([summary.devices.length, summary.totalInterfaces, summary.totalUnmonitored, summary.totalDown].map(escape).join(';'));
    rows.push('');
    // Devices section
    rows.push('Dispositivos');
    rows.push('displayName;deviceName;ipaddress;statusStr;category;type');
    summary.devices.forEach(d => {
      rows.push([d.displayName || d.deviceName || d['name'] || '', d.deviceName || '', d.ipaddress || d['ip'] || '', d.statusStr || '', d.category || '', d.type || ''].map(escape).join(';'));
    });
    rows.push('');
    // Interfaces section
    rows.push('Interfaces');
    rows.push('deviceName;interfaceName;ipaddress;type;status;managed');
    summary.interfaces.forEach(i => {
      const isManaged = i.managed === 'true' || i.managed === true || i.isManaged === 'true' || i.isManaged === true || i.monitor === 'true' || i.monitor === true;
      rows.push([i.deviceName || i.displayName || '', i.interfaceDisplayName || i.name || '', i.ipAddress || i.ipaddress || '', i.type || i.interfaceType || '', i.status || i.operStatus || '', isManaged ? 'Yes' : 'No'].map(escape).join(';'));
    });
    const csvContent = rows.join('\n');
    const blob = new Blob([csvContent], {
      type: 'text/csv;charset=utf-8;'
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'opmanager_sre_audit.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
  trackLog(_index, item) {
    return item.timestamp?.toISOString?.() + item.message;
  }
  static #_ = _staticBlock = () => (this.ɵfac = function SreAuditPage_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || SreAuditPage)(_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdirectiveInject"](_services_sre_audit_service__WEBPACK_IMPORTED_MODULE_5__.SreAuditService));
  }, this.ɵcmp = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵdefineComponent"]({
    type: SreAuditPage,
    selectors: [["app-sre-audit"]],
    decls: 39,
    vars: 24,
    consts: [[1, "ion-padding", "sre-audit-content"], ["size", "12", "size-md", "4"], ["expand", "block", "color", "primary", 3, "click", "disabled"], ["expand", "block", "color", "medium", 1, "ion-margin-top", 3, "click", "disabled"], ["class", "ion-margin-top ion-text-center", 4, "ngIf"], [4, "ngIf"], ["size", "12", "size-md", "8"], [1, "log-card"], [1, "log-console"], ["class", "log-line", 3, "ngClass", 4, "ngFor", "ngForOf", "ngForTrackBy"], [1, "ion-margin-top", "ion-text-center"], ["name", "crescent"], ["color", "success"], ["slot", "end"], ["slot", "end", "color", "warning"], ["slot", "end", "color", "danger"], ["expand", "block", "color", "success", 1, "ion-margin-top", 3, "click"], ["name", "download", "slot", "start"], ["color", "danger"], [1, "log-line", 3, "ngClass"], [1, "log-time"], [1, "log-level"], [1, "log-message"]],
    template: function SreAuditPage_Template(rf, ctx) {
      if (rf & 1) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](0, "ion-header")(1, "ion-toolbar")(2, "ion-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](3, "OpManager MSP - SRE");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](4, "ion-content", 0)(5, "ion-grid")(6, "ion-row")(7, "ion-col", 1)(8, "ion-card")(9, "ion-card-header")(10, "ion-card-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](11, "Modos de ejecuci\u00F3n");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](12, "ion-card-content")(13, "ion-button", 2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](14, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function SreAuditPage_Template_ion_button_click_13_listener() {
          return ctx.runQuick();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](15, " \u26A1 Modo R\u00C1PIDO (solo reporte) ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](16, "ion-button", 3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](17, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵlistener"]("click", function SreAuditPage_Template_ion_button_click_16_listener() {
          return ctx.runFull();
        });
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](18, " \uD83D\uDD04 Proceso completo (con actualizaci\u00F3n) ");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](19, SreAuditPage_div_19_Template, 4, 0, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](20, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](21, SreAuditPage_div_21_Template, 3, 0, "div", 4);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](22, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](23, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](24, SreAuditPage_ion_card_24_Template, 29, 4, "ion-card", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](25, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](26, SreAuditPage_ion_card_26_Template, 7, 1, "ion-card", 5);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](27, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](28, "ion-col", 6)(29, "ion-card", 7)(30, "ion-card-header")(31, "ion-card-title");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](32, "Monitor de Logs");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](33, "ion-card-subtitle");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtext"](34, "Pasos del proceso en tiempo real");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()();
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementStart"](35, "ion-card-content")(36, "div", 8);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵtemplate"](37, SreAuditPage_div_37_Template, 8, 11, "div", 9);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipe"](38, "async");
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵelementEnd"]()()()()()()();
      }
      if (rf & 2) {
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](13);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("disabled", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](14, 8, ctx.running$));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("disabled", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](17, 10, ctx.running$));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](20, 12, ctx.running$));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", !_angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](22, 14, ctx.running$) && _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](23, 16, ctx.mode$));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](3);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](25, 18, ctx.summary$));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](2);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngIf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](27, 20, ctx.error$));
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵadvance"](11);
        _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵproperty"]("ngForOf", _angular_core__WEBPACK_IMPORTED_MODULE_4__["ɵɵpipeBind1"](38, 22, ctx.logs$))("ngForTrackBy", ctx.trackLog);
      }
    },
    dependencies: [_angular_common__WEBPACK_IMPORTED_MODULE_0__.CommonModule, _angular_common__WEBPACK_IMPORTED_MODULE_0__.NgClass, _angular_common__WEBPACK_IMPORTED_MODULE_0__.NgForOf, _angular_common__WEBPACK_IMPORTED_MODULE_0__.NgIf, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonicModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonButton, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonCard, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonCardContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonCardHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonCardSubtitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonCardTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonCol, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonContent, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonGrid, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonHeader, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonIcon, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonItem, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonLabel, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonList, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonNote, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonRow, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonSpinner, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonText, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonTitle, _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.IonToolbar, _angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule, _angular_common__WEBPACK_IMPORTED_MODULE_0__.AsyncPipe, _angular_common__WEBPACK_IMPORTED_MODULE_0__.DatePipe],
    styles: [".sre-audit-content[_ngcontent-%COMP%] {\n  --background: var(--ion-color-light);\n}\n\n.log-card[_ngcontent-%COMP%] {\n  height: 100%;\n}\n\n.log-console[_ngcontent-%COMP%] {\n  background: #111;\n  color: #f5f5f5;\n  font-family: Menlo, Monaco, Consolas, \"Courier New\", monospace;\n  font-size: 12px;\n  padding: 8px;\n  border-radius: 4px;\n  max-height: 60vh;\n  overflow-y: auto;\n}\n\n.log-line[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: baseline;\n  padding: 2px 0;\n}\n\n.log-time[_ngcontent-%COMP%] {\n  color: #888;\n  margin-right: 8px;\n}\n\n.log-level[_ngcontent-%COMP%] {\n  margin-right: 8px;\n}\n\n.log-message[_ngcontent-%COMP%] {\n  white-space: pre-wrap;\n}\n\n.log-info[_ngcontent-%COMP%]   .log-level[_ngcontent-%COMP%] {\n  color: #4caf50;\n}\n\n.log-warn[_ngcontent-%COMP%]   .log-level[_ngcontent-%COMP%] {\n  color: #ffc107;\n}\n\n.log-error[_ngcontent-%COMP%]   .log-level[_ngcontent-%COMP%] {\n  color: #f44336;\n}\n/*# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8uL3NyYy9hcHAvc3JlLWF1ZGl0L3NyZS1hdWRpdC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxvQ0FBQTtBQUNGOztBQUVBO0VBQ0UsWUFBQTtBQUNGOztBQUVBO0VBQ0UsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsOERBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtBQUNGOztBQUVBO0VBQ0UsYUFBQTtFQUNBLHFCQUFBO0VBQ0EsY0FBQTtBQUNGOztBQUVBO0VBQ0UsV0FBQTtFQUNBLGlCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxpQkFBQTtBQUNGOztBQUVBO0VBQ0UscUJBQUE7QUFDRjs7QUFFQTtFQUNFLGNBQUE7QUFDRjs7QUFFQTtFQUNFLGNBQUE7QUFDRjs7QUFFQTtFQUNFLGNBQUE7QUFDRiIsInNvdXJjZXNDb250ZW50IjpbIi5zcmUtYXVkaXQtY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcbn1cblxuLmxvZy1jYXJkIHtcbiAgaGVpZ2h0OiAxMDAlO1xufVxuXG4ubG9nLWNvbnNvbGUge1xuICBiYWNrZ3JvdW5kOiAjMTExO1xuICBjb2xvcjogI2Y1ZjVmNTtcbiAgZm9udC1mYW1pbHk6IE1lbmxvLCBNb25hY28sIENvbnNvbGFzLCBcIkNvdXJpZXIgTmV3XCIsIG1vbm9zcGFjZTtcbiAgZm9udC1zaXplOiAxMnB4O1xuICBwYWRkaW5nOiA4cHg7XG4gIGJvcmRlci1yYWRpdXM6IDRweDtcbiAgbWF4LWhlaWdodDogNjB2aDtcbiAgb3ZlcmZsb3cteTogYXV0bztcbn1cblxuLmxvZy1saW5lIHtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGJhc2VsaW5lO1xuICBwYWRkaW5nOiAycHggMDtcbn1cblxuLmxvZy10aW1lIHtcbiAgY29sb3I6ICM4ODg7XG4gIG1hcmdpbi1yaWdodDogOHB4O1xufVxuXG4ubG9nLWxldmVsIHtcbiAgbWFyZ2luLXJpZ2h0OiA4cHg7XG59XG5cbi5sb2ctbWVzc2FnZSB7XG4gIHdoaXRlLXNwYWNlOiBwcmUtd3JhcDtcbn1cblxuLmxvZy1pbmZvIC5sb2ctbGV2ZWwge1xuICBjb2xvcjogIzRjYWY1MDtcbn1cblxuLmxvZy13YXJuIC5sb2ctbGV2ZWwge1xuICBjb2xvcjogI2ZmYzEwNztcbn1cblxuLmxvZy1lcnJvciAubG9nLWxldmVsIHtcbiAgY29sb3I6ICNmNDQzMzY7XG59XG4iXSwic291cmNlUm9vdCI6IiJ9 */"]
  }));
}
_staticBlock();

/***/ }),

/***/ 2020:
/*!***********************************************!*\
  !*** ./src/app/services/sre-audit.service.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SreAuditService: () => (/* binding */ SreAuditService)
/* harmony export */ });
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 3942);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 5797);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 9452);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 1318);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 271);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 6647);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs */ 8764);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 4205);
/* harmony import */ var _opmanager_api_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./opmanager-api.service */ 5793);
var _staticBlock;



class SreAuditService {
  constructor(api) {
    this.api = api;
    // Default values based on the Apps Script CONFIG
    this.defaultConfig = {
      selCustomerID: '901',
      regionID: '-1',
      category: 'Firewall',
      highlightUnmonitored: true,
      detectChanges: true,
      autoMonitorCritical: false,
      batchSize: 5,
      skipUpdateInterfaces: true,
      delayBetweenRequestsMs: 300
    };
    this.logs$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject([]);
    this.running$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(false);
    this.mode$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(null);
    this.error$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(null);
    this.summary$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__.BehaviorSubject(null);
  }
  clear() {
    this.logs$.next([]);
    this.error$.next(null);
    this.summary$.next(null);
    this.mode$.next(null);
  }
  startQuickMode(customConfig) {
    const config = {
      ...this.defaultConfig,
      ...customConfig
    };
    this.clear();
    this.mode$.next('quick');
    this.running$.next(true);
    this.log('info', '=== MODO RÁPIDO - SIN ACTUALIZACIÓN ===');
    return this.loadDevicesAndInterfaces(config).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.tap)(({
      devices,
      interfaces
    }) => {
      if (!devices.length) {
        this.log('warn', 'No se encontraron dispositivos para procesar.');
        this.running$.next(false);
        return;
      }
      const summary = this.buildSummary(devices, interfaces, config);
      this.summary$.next(summary);
      this.log('info', `Dispositivos: ${devices.length}`);
      this.log('info', `Interfaces: ${interfaces.length}`);
      this.log('info', 'Reporte SRE generado en memoria (puede visualizarse en la UI).');
      this.log('info', '=== COMPLETADO ===');
      this.running$.next(false);
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.map)(() => this.summary$.value), (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.catchError)(err => {
      const msg = String(err?.message || err);
      this.error$.next(msg);
      this.log('error', `ERROR: ${msg}`);
      this.running$.next(false);
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.of)(null);
    }));
  }
  startFullProcess(customConfig) {
    const config = {
      ...this.defaultConfig,
      ...customConfig
    };
    this.clear();
    this.mode$.next('full');
    this.running$.next(true);
    this.log('info', '=== INICIANDO PROCESO SRE ===');
    return this.loadDevices(config).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.switchMap)(devices => {
      if (!devices.length) {
        this.log('warn', 'No se encontraron dispositivos para procesar.');
        this.running$.next(false);
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.of)({
          devices: [],
          interfaces: []
        });
      }
      this.log('info', `1. Dispositivos obtenidos: ${devices.length}`);
      this.log('info', '2. Obteniendo interfaces y estado de monitoreo...');
      return this.loadInterfaces(config).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.switchMap)(interfaces => {
        this.log('info', `   Total de interfaces obtenidas: ${interfaces.length}`);
        if (config.skipUpdateInterfaces) {
          this.log('info', '3. ⚡ MODO RÁPIDO: Saltando actualización de interfaces');
          return (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.of)({
            devices,
            interfaces
          });
        }
        this.log('info', '3. Procesando y actualizando interfaces por dispositivo...');
        return this.processAndUpdateInterfaces(devices, interfaces, config).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.switchMap)(() => {
          this.log('info', '4. Obteniendo interfaces actualizadas...');
          return this.loadInterfaces(config).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.map)(updatedInterfaces => ({
            devices,
            interfaces: updatedInterfaces
          })));
        }));
      }));
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_6__.tap)(({
      devices,
      interfaces
    }) => {
      const summary = this.buildSummary(devices, interfaces, config);
      this.summary$.next(summary);
      this.log('info', '5. Generando reporte SRE (en memoria)...');
      this.log('info', '6. Generando resumen ejecutivo (en memoria)...');
      this.log('info', '=== PROCESO COMPLETADO EXITOSAMENTE ===');
      this.running$.next(false);
    }), (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.map)(() => this.summary$.value), (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.catchError)(err => {
      const msg = String(err?.message || err);
      this.error$.next(msg);
      this.log('error', `ERROR: ${msg}`);
      this.running$.next(false);
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.of)(null);
    }));
  }
  loadDevices(config) {
    const params = {
      selCustomerID: config.selCustomerID,
      regionID: config.regionID,
      category: config.category
    };
    this.log('info', '1. Obteniendo dispositivos...');
    return this.api.getDevices(params).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.tap)(devices => this.log('info', `   Dispositivos obtenidos: ${devices.length}`)));
  }
  loadInterfaces(config) {
    const params = {
      selCustomerID: config.selCustomerID,
      regionID: config.regionID
    };
    this.log('info', '2. Obteniendo interfaces y estado de monitoreo...');
    return this.api.listInterfaces(params).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.tap)(interfaces => this.log('info', `   Total de interfaces obtenidas: ${interfaces.length}`)));
  }
  loadDevicesAndInterfaces(config) {
    return this.loadDevices(config).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.switchMap)(devices => this.loadInterfaces(config).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_4__.map)(interfaces => ({
      devices,
      interfaces
    })))));
  }
  processAndUpdateInterfaces(devices, interfaces, config) {
    if (!devices.length || !interfaces.length) {
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.of)(void 0);
    }
    const batches = [];
    for (let i = 0; i < devices.length; i += config.batchSize) {
      batches.push(devices.slice(i, i + config.batchSize));
    }
    const runBatch = batchIndex => {
      if (batchIndex >= batches.length) {
        return (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.of)(void 0);
      }
      const batch = batches[batchIndex];
      const updates$ = batch.map((device, idx) => {
        const display = (device.displayName || device.deviceName || '').toString();
        this.log('info', `   [${batchIndex * config.batchSize + idx + 1}/${devices.length}] Procesando: ${display}`);
        const deviceName = device.deviceName || device['name'];
        if (!deviceName) {
          this.log('warn', '      Dispositivo sin deviceName, se omite.');
          return (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.of)(false);
        }
        const ifaceForDevice = interfaces.filter(itf => String(itf['deviceName'] ?? itf['displayName'] ?? '').toLowerCase() === deviceName.toLowerCase());
        if (!ifaceForDevice.length) {
          this.log('info', '      Sin interfaces para este dispositivo, se omite actualización.');
          return (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.of)(false);
        }
        const ids = Array.from({
          length: ifaceForDevice.length
        }, (_, i) => String(i + 1));
        return this.api.updateInterfaces(deviceName, ids, config.regionID, config.selCustomerID).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_6__.tap)(ok => {
          if (ok) {
            this.log('info', `      Actualizado: ${ifaceForDevice.length} interfaces`);
          } else {
            this.log('warn', '      Falló la actualización de interfaces.');
          }
        }));
      });
      // Execute sequentially inside batch to keep logs ordered
      return updates$.reduce((acc, obs) => acc.pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.switchMap)(() => obs), (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.switchMap)(() => this.delay(config.delayBetweenRequestsMs))), (0,rxjs__WEBPACK_IMPORTED_MODULE_2__.of)(void 0)).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_5__.switchMap)(() => runBatch(batchIndex + 1)));
    };
    return runBatch(0);
  }
  buildSummary(devices, interfaces, config) {
    let totalUnmonitored = 0;
    let totalDown = 0;
    interfaces.forEach(itf => {
      const isMonitored = itf['managed'] === 'true' || itf['managed'] === true || itf['isManaged'] === 'true' || itf['isManaged'] === true || itf['monitor'] === 'true' || itf['monitor'] === true;
      const status = String(itf['status'] ?? itf['operStatus'] ?? '').toLowerCase();
      if (!isMonitored) {
        totalUnmonitored++;
      }
      if (status === 'down') {
        totalDown++;
      }
    });
    return {
      devices,
      interfaces,
      totalInterfaces: interfaces.length,
      totalUnmonitored,
      totalDown
    };
  }
  delay(ms) {
    return new rxjs__WEBPACK_IMPORTED_MODULE_0__.Observable(observer => {
      const handle = setTimeout(() => {
        observer.next();
        observer.complete();
      }, ms);
      return () => clearTimeout(handle);
    });
  }
  log(level, message) {
    const next = {
      timestamp: new Date(),
      level,
      message
    };
    const current = this.logs$.value;
    this.logs$.next([...current, next]);
    // Also mirror to console for debugging
    // eslint-disable-next-line no-console
    console[level === 'error' ? 'error' : level === 'warn' ? 'warn' : 'log']('[SRE]', message);
  }
  static #_ = _staticBlock = () => (this.ɵfac = function SreAuditService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || SreAuditService)(_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵinject"](_opmanager_api_service__WEBPACK_IMPORTED_MODULE_8__.OpmanagerApiService));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineInjectable"]({
    token: SreAuditService,
    factory: SreAuditService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();

/***/ })

}]);
//# sourceMappingURL=default-src_app_sre-audit_sre-audit_module_ts.js.map