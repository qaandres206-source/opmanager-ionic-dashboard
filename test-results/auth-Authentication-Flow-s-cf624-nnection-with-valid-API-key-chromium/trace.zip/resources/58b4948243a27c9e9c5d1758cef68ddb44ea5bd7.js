"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_services_opmanager-api_service_ts"],{

/***/ 5312:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   environment: () => (/* binding */ environment)
/* harmony export */ });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
  production: false,
  opmanagerApiUrl: 'https://itview.intwo.cloud/api'
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.

/***/ }),

/***/ 5793:
/*!***************************************************!*\
  !*** ./src/app/services/opmanager-api.service.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   OpmanagerApiService: () => (/* binding */ OpmanagerApiService)
/* harmony export */ });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common/http */ 3855);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 9452);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ 271);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 1318);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../environments/environment */ 5312);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 4205);
var _staticBlock;






class OpmanagerApiService {
  constructor(http) {
    this.http = http;
    this.STORAGE_KEY = 'opmanagerApiKey';
    this.baseUrl = _environments_environment__WEBPACK_IMPORTED_MODULE_4__.environment.opmanagerApiUrl ?? 'https://itview.intwo.cloud/api';
    // Log environment info for debugging
    console.log('[OpManagerApiService] Initializing...', {
      production: _environments_environment__WEBPACK_IMPORTED_MODULE_4__.environment.production,
      configuredUrl: _environments_environment__WEBPACK_IMPORTED_MODULE_4__.environment.opmanagerApiUrl,
      finalBaseUrl: this.baseUrl
    });
    // During development, use the dev proxy at /api to avoid CORS issues when running ionic serve
    try {
      if (typeof window !== 'undefined' && window.location && window.location.hostname.includes('localhost')) {
        this.baseUrl = '/api';
        console.log('[OpManagerApiService] Localhost detected, switching to /api proxy');
      }
    } catch (e) {
      // noop
    }
  }
  get apiKey() {
    return localStorage.getItem(this.STORAGE_KEY);
  }
  set apiKey(value) {
    if (value) {
      localStorage.setItem(this.STORAGE_KEY, value);
    } else {
      localStorage.removeItem(this.STORAGE_KEY);
    }
  }
  authenticate() {
    if (!this.apiKey) {
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.of)(false);
    }
    const params = this.buildParams();
    const url = `${this.baseUrl}/json/v2/device/listDevices`;
    const headers = this.buildHeaders();
    this.debugLogRequest('GET', url, params, headers);
    return this.http.get(url, {
      params,
      headers
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.map)(data => {
      if (!data) {
        return false;
      }
      if (typeof data === 'object' && 'error' in data) {
        return false;
      }
      return true;
    }));
  }
  getDashboardData(extraParams) {
    return this.getDevices(extraParams).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.map)(devices => {
      const total_devices = devices.length;
      const alerts = []; // Alerts can be wired later or via getAlarms
      const active_alerts = alerts.filter(a => a.status === 'active' || a.severity === 'critical').length;
      const devices_by_status = {};
      devices.forEach(device => {
        let status = String(device['statusStr'] ?? 'unknown').toLowerCase();
        if (status === 'clear') {
          status = 'healthy';
        } else if (['warning', 'minor'].includes(status)) {
          status = 'warning';
        } else if (['critical', 'major'].includes(status)) {
          status = 'critical';
        }
        devices_by_status[status] = (devices_by_status[status] ?? 0) + 1;
      });
      return {
        total_devices,
        active_alerts,
        devices_by_status,
        recent_alerts: alerts,
        devices
      };
    }));
  }
  getHealthSummary() {
    return this.getDevices().pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.map)(devices => {
      const summary = {
        healthy: 0,
        warning: 0,
        critical: 0,
        unknown: 0
      };
      devices.forEach(device => {
        const rawStatus = String(device['statusStr'] ?? 'unknown').toLowerCase();
        if (rawStatus === 'clear') {
          summary.healthy++;
        } else if (['warning', 'minor'].includes(rawStatus)) {
          summary.warning++;
        } else if (['critical', 'major'].includes(rawStatus)) {
          summary.critical++;
        } else {
          summary.unknown++;
        }
      });
      return summary;
    }));
  }
  getDevices(extraParams) {
    if (!this.apiKey) {
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.of)([]);
    }
    const params = this.buildParams(extraParams);
    const url = `${this.baseUrl}/json/v2/device/listDevices`;
    const headers = this.buildHeaders();
    this.debugLogRequest('GET', url, params, headers);
    return this.http.get(url, {
      params,
      headers
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.map)(result => {
      if (result && Array.isArray(result.rows)) {
        return result.rows;
      }
      if (Array.isArray(result)) {
        return result;
      }
      if (result && Array.isArray(result.devices)) {
        return result.devices;
      }
      return [];
    }));
  }
  /** Alarm endpoints **/
  getAlarms(params) {
    if (!this.apiKey) {
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.of)([]);
    }
    const httpParams = this.buildParams(params ?? {});
    const url = `${this.baseUrl}/json/alarm/listAlarms`;
    const headers = this.buildHeaders();
    this.debugLogRequest('GET', url, httpParams, headers);
    return this.http.get(url, {
      params: httpParams,
      headers
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.map)(result => {
      if (Array.isArray(result)) {
        return result;
      }
      if (result && Array.isArray(result.alarms)) {
        return result.alarms;
      }
      if (result && Array.isArray(result.alerts)) {
        return result.alerts;
      }
      if (result && Array.isArray(result.rows)) {
        return result.rows;
      }
      return [];
    }));
  }
  getTopDevicesByAlarms(eventType) {
    if (!this.apiKey) {
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.of)([]);
    }
    const params = this.buildParams({
      eventType
    });
    const url = `${this.baseUrl}/json/alarm/getTopDevicesByAlarms`;
    const headers = this.buildHeaders();
    this.debugLogRequest('GET', url, params, headers);
    return this.http.get(url, {
      params,
      headers
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.map)(result => {
      if (Array.isArray(result)) {
        return result;
      }
      if (result && Array.isArray(result.devices)) {
        return result.devices;
      }
      return [];
    }));
  }
  /** Device monitor / performance endpoints **/
  getDeviceAssociatedMonitors(name) {
    if (!this.apiKey) {
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.of)([]);
    }
    const params = this.buildParams({
      name
    });
    const url = `${this.baseUrl}/json/device/getDeviceAssociatedMonitors`;
    const headers = this.buildHeaders();
    this.debugLogRequest('GET', url, params, headers);
    return this.http.get(url, {
      params,
      headers
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.map)(result => Array.isArray(result) ? result : result?.monitors ?? []));
  }
  getPerformanceMonitors(deviceName, category, type) {
    if (!this.apiKey) {
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.of)([]);
    }
    const params = {
      deviceName
    };
    if (category) params['category'] = category;
    if (type) params['type'] = type;
    const httpParams = this.buildParams(params);
    const url = `${this.baseUrl}/json/device/getPerformanceMonitors`;
    const headers = this.buildHeaders();
    this.debugLogRequest('GET', url, httpParams, headers);
    return this.http.get(url, {
      params: httpParams,
      headers
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.map)(result => Array.isArray(result) ? result : result?.monitors ?? []));
  }
  /** Ping / trace endpoints (POST) **/
  postPingResponse(deviceName) {
    if (!this.apiKey) {
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.of)(null);
    }
    const params = this.buildParams({
      deviceName
    });
    const url = `${this.baseUrl}/json/device/getPingResponse`;
    const headers = this.buildHeaders();
    this.debugLogRequest('POST', url, params, headers);
    return this.http.post(url, null, {
      params,
      headers
    });
  }
  postTraceResponse(deviceName) {
    if (!this.apiKey) {
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.of)(null);
    }
    const params = this.buildParams({
      deviceName
    });
    const url = `${this.baseUrl}/json/device/getTraceResponse`;
    const headers = this.buildHeaders();
    this.debugLogRequest('POST', url, params, headers);
    return this.http.post(url, null, {
      params,
      headers
    });
  }
  /** Events endpoints **/
  getEvents(params) {
    if (!this.apiKey) {
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.of)([]);
    }
    const httpParams = this.buildParams(params ?? {});
    const url = `${this.baseUrl}/json/events/listEvents`;
    const headers = this.buildHeaders();
    this.debugLogRequest('GET', url, httpParams, headers);
    return this.http.get(url, {
      params: httpParams,
      headers
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.map)(result => {
      if (Array.isArray(result)) {
        return result;
      }
      if (result && Array.isArray(result.events)) {
        return result.events;
      }
      if (result && Array.isArray(result.rows)) {
        return result.rows;
      }
      return [];
    }));
  }
  /** Interface endpoints **/
  listInterfaces(params) {
    if (!this.apiKey) {
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.of)([]);
    }
    const httpParams = this.buildParams(params ?? {});
    const url = `${this.baseUrl}/json/device/listInterfaces`;
    const headers = this.buildHeaders();
    this.debugLogRequest('GET', url, httpParams, headers);
    return this.http.get(url, {
      params: httpParams,
      headers: headers
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.map)(result => {
      if (result && Array.isArray(result.rows)) {
        return result.rows;
      }
      if (result && Array.isArray(result.interfaces)) {
        return result.interfaces;
      }
      if (Array.isArray(result)) {
        return result;
      }
      return [];
    }));
  }
  /** SRE / discovery endpoints (based on Google Apps Script) **/
  updateInterfaces(deviceName, interfaceIDs, regionId = '-1', selCustomerID) {
    if (!this.apiKey) {
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.of)(false);
    }
    const idsStr = JSON.stringify(interfaceIDs);
    // We build params manually here because the discovery endpoint expects specific query params
    const params = {
      deviceName,
      interfaceIDs: idsStr,
      update: 'true',
      selCustomerID: selCustomerID ?? '-1',
      regionID: regionId
    };
    const httpParams = this.buildParams(params);
    const url = `${this.baseUrl}/json/discovery/updateInterfaces`;
    const headers = this.buildHeaders();
    this.debugLogRequest('GET', url, httpParams, headers);
    return this.http.get(url, {
      params: httpParams,
      headers
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.map)(res => {
      // Treat HTTP 200 with any body as success; you can refine based on real API response
      return !!res;
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(() => (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.of)(false)));
  }
  getInterfaceSummary(interfaceName) {
    if (!this.apiKey) {
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.of)({});
    }
    const params = this.buildParams({
      interfaceName
    });
    const url = `${this.baseUrl}/json/device/getInterfaceSummary`;
    const headers = this.buildHeaders();
    this.debugLogRequest('GET', url, params, headers);
    return this.http.get(url, {
      params,
      headers
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.map)(result => result ?? {}), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(() => (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.of)({})));
  }
  getInterfaceGraphs(interfaceName, graphName = 'traffic', period = '6') {
    if (!this.apiKey) {
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.of)({});
    }
    const params = this.buildParams({
      interfaceName,
      graphName,
      isFluidic: 'true',
      period
    });
    const url = `${this.baseUrl}/json/device/getInterfaceGraphs`;
    const headers = this.buildHeaders();
    this.debugLogRequest('GET', url, params, headers);
    return this.http.get(url, {
      params,
      headers
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.map)(result => result ?? {}), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.catchError)(() => (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.of)({})));
  }
  getCustomers() {
    if (!this.apiKey) {
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.of)([]);
    }
    const params = this.buildParams();
    const url = `${this.baseUrl}/json/admin/listCustomerNames`;
    const headers = this.buildHeaders();
    this.debugLogRequest('GET', url, params, headers);
    return this.http.get(url, {
      params,
      headers
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.map)(result => {
      if (Array.isArray(result)) {
        return result;
      }
      if (result && Array.isArray(result.customers)) {
        return result.customers;
      }
      return [];
    }));
  }
  getDeviceNotes(deviceName) {
    if (!this.apiKey) {
      return (0,rxjs__WEBPACK_IMPORTED_MODULE_1__.of)(null);
    }
    const params = this.buildParams({
      name: deviceName
    });
    const url = `${this.baseUrl}/json/device/getDeviceNotes`;
    const headers = this.buildHeaders();
    this.debugLogRequest('GET', url, params, headers);
    return this.http.get(url, {
      params,
      headers
    }).pipe((0,rxjs__WEBPACK_IMPORTED_MODULE_2__.map)(result => result ?? {}));
  }
  buildParams(extraParams) {
    let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_0__.HttpParams().set('selCustomerID', '-1').set('regionID', '-1');
    if (extraParams) {
      Object.entries(extraParams).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          params = params.set(key, String(value));
        }
      });
    }
    return params;
  }
  buildHeaders() {
    let headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_0__.HttpHeaders({
      'Content-Type': 'application/json'
    });
    if (this.apiKey) {
      headers = headers.set('apiKey', this.apiKey);
    }
    return headers;
  }
  debugLogRequest(method, url, params, headers) {
    try {
      const paramsStr = params?.toString() ?? '';
      const headerObj = {};
      headers?.keys().forEach(k => {
        const vals = headers.getAll(k) ?? [];
        headerObj[k] = vals.length > 1 ? vals : vals[0] ?? '';
      });
      // eslint-disable-next-line no-console
      console.debug('[OpManager API] Request', {
        method,
        url,
        params: paramsStr,
        headers: headerObj
      });
    } catch (e) {
      // eslint-disable-next-line no-console
      console.debug('[OpManager API] DebugLog failed', e);
    }
  }
  static #_ = _staticBlock = () => (this.ɵfac = function OpmanagerApiService_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || OpmanagerApiService)(_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_0__.HttpClient));
  }, this.ɵprov = /*@__PURE__*/_angular_core__WEBPACK_IMPORTED_MODULE_5__["ɵɵdefineInjectable"]({
    token: OpmanagerApiService,
    factory: OpmanagerApiService.ɵfac,
    providedIn: 'root'
  }));
}
_staticBlock();

/***/ })

}]);
//# sourceMappingURL=default-src_app_services_opmanager-api_service_ts.js.map